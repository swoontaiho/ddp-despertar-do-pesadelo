/* Estantes 3D de livros — feitas só com código (Three.js). Sem arquivos de modelo.
   API: Shelf3D.init(host, { onOpen(id), onFail(msg) });  Shelf3D.setData(rows);  Shelf3D.setActive(bool);
        Shelf3D.select(idDaEstante);  Shelf3D.back();
   rows = [{ id:'arma', label:'Armas', books:[{ id, name, grau, no, image }] }, ...]
   v3: uma estante por tipo de item (uma atrás da outra, escolha pelas abas ou tocando na que aparece atrás),
       um andar por grau, livros de capa dura detalhados (couro, relevo, dourado, páginas), sem imagem na capa
       (a imagem só aparece dentro do livro, nas informações). Clicar num livro o traz para perto da tela,
       com o botão "Abrir livro" — só então as informações aparecem. */
(function(){
  'use strict';
  var T = window.THREE;
  var S = { ready:false };
  window.Shelf3D = S;

  var GRAU_COL = { especial:'#E9C766', '1':'#C9645A', '2':'#6FA79A', '3':'#B8A276', '4':'#AFA99B', calamidade:'#C0392B', '':'#8c8c8c' };
  var GRAU_TXT = { especial:'Grau Especial', '1':'Grau 1', '2':'Grau 2', '3':'Grau 3', '4':'Grau 4', calamidade:'Calamidade', '':'Sem grau' };
  var GRAU_PLATE = { especial:'Especial', '1':'Grau 1', '2':'Grau 2', '3':'Grau 3', '4':'Grau 4', calamidade:'Calamidade', '':'Sem grau' };
  var GRAU_BASE = { especial:'#4A3510', '1':'#7E3029', '2':'#2C5A50', '3':'#6A5731', '4':'#52514A', calamidade:'#58100A', '':'#3A3A44' };
  var PALETTE = ['#7A2E2E', '#2F5D4A', '#2E3F6E', '#8A5A2B', '#5A2E6B', '#1F5A6B', '#3A3A44', '#8B3A1F', '#4E5B2A', '#6B2D4A'];
  var GLOSSY = { especial:1, calamidade:1, '1':1 };
  var FLOORS = ['calamidade', 'especial', '1', '2', '3', '4', ''];     // de cima para baixo

  var host, canvasHost, renderer, scene, camera, root, sun, featLight, dimPlane, ro;
  var tipEl, msgEl, tabsEl, veilEl, featEl, capEl, hintEl, rdEl, rdPos, rdPrev, rdNext;
  var opts = {}, active = true, running = false, raf = 0, lastT = 0, timeS = 0;
  var lastData = [], cases = [], selIdx = 0, selId = null, pendingData = false, buildToken = 0;
  var woodTex, pageTex, spineBump, leatherA, leatherB, envOn = false;
  var matCache = {};
  var yaw = 0, yawVel = 0, pitch = 0.09, zoom = 1;
  var fitW = 12, fitTop = 14, tgtW = 12, tgtTop = 14;
  var featBook = null, featYaw = 0.34, featTilt = 0.07, FDIST = 7, full = false, fullPrev = '', hostPrevH = '';
  var ray, mouse, hovered = null, hoverShelf = -1, drag = null;
  var D = 1.6, LH = 2.15, BT = 0.24, YB = -0.58;
  var SIDE_ANG = 1.2, GX = 5.4, ZG = 1.4;        // corredores: estantes ao lado ficam viradas de lado (≈64°), cada uma um pouco mais afastada
  var AX_Y = new T.Vector3(0, 1, 0), AX_X = new T.Vector3(1, 0, 0);
  var tV = new T.Vector3(), tQ = new T.Quaternion(), tQ2 = new T.Quaternion(), camQ = new T.Quaternion(), parQ = new T.Quaternion();

  function hash(str){ var h = 2166136261; for(var i = 0; i < str.length; i++){ h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0); }
  function rnd(seed){ var s = seed >>> 0; return function(){ s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; }
  function mkCanvas(w, h){ var c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
  function tex(c, linear, shared){
    var t = new T.CanvasTexture(c);
    t.encoding = linear ? T.LinearEncoding : T.sRGBEncoding;
    t.anisotropy = 4; t.generateMipmaps = true; t.minFilter = T.LinearMipmapLinearFilter; t.magFilter = T.LinearFilter;
    t.s3dOwn = !shared; return t;
  }
  function shade(hex, amt){
    var n = parseInt(hex.slice(1), 16), r = (n >> 16) + amt, g = ((n >> 8) & 255) + amt, b = (n & 255) + amt;
    r = Math.max(0, Math.min(255, r)); g = Math.max(0, Math.min(255, g)); b = Math.max(0, Math.min(255, b));
    return '#' + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1);
  }
  function fitFont(g, text, maxW, size, min, weight){
    while(size > min){ g.font = (weight || '700') + ' ' + size + 'px Fraunces, Georgia, serif'; if(g.measureText(text).width <= maxW) break; size -= 2; }
    return size;
  }
  function gkey(g){ return (g === undefined || g === null) ? '' : String(g); }
  function ease(t){ t = Math.max(0, Math.min(1, t)); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }
  function ap(rate, dt){ return 1 - Math.exp(-rate * dt); }

  /* ---------- CSS da interface (abas, botões) ---------- */
  function injectCss(){
    if(document.getElementById('s3d-css')) return;
    var st = document.createElement('style'); st.id = 's3d-css';
    st.textContent =
      '.s3d-tabs{display:flex;flex-wrap:nowrap;overflow-x:auto;gap:8px;padding:8px 4px 12px;position:relative;z-index:3;scrollbar-width:none}.s3d-tab{flex:0 0 auto;white-space:nowrap}' +
      '.s3d-tabs[hidden]{display:none}' +
      '.s3d-tab{font-family:"Space Mono",monospace;font-size:13px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;padding:10px 15px;border:1.5px solid var(--ink,#1B2A22);background:rgba(255,253,246,.85);color:var(--ink,#1B2A22);cursor:var(--cur-hand,pointer);display:inline-flex;gap:8px;align-items:center;transition:background .15s,color .15s}' +
      '.s3d-tab small{opacity:1;font-size:12px;font-weight:700;color:#6B4C0A}.s3d-tab.on small{color:#E9C766}' +
      '.s3d-tab:hover{background:#D9CBAE}' +
      '.s3d-tab.on{background:var(--ink,#1B2A22);color:#FFF8E6}' +
      '.s3d-canvas{position:relative}' +
      '.s3d-canvas canvas{position:relative;z-index:1}' +
      '.s3d-veil{position:absolute;inset:0;z-index:0;opacity:0;pointer-events:none;transition:opacity .45s ease;background:radial-gradient(ellipse at 50% 38%,rgba(58,42,28,.55),rgba(10,7,5,.94))}' +
      '.s3d-veil.on{opacity:1}' +
      '.s3d-canvas.s3d-full{position:fixed!important;left:0;top:0;width:100vw!important;z-index:50;min-height:0!important}' +
      '.s3d-canvas.s3d-full canvas{touch-action:none!important;cursor:var(--cur-grab,grab)}' +
      '.s3d-feat{position:absolute;left:0;right:0;bottom:0;z-index:3;display:flex;gap:12px;justify-content:center;flex-wrap:wrap;padding:12px 14px calc(20px + env(safe-area-inset-bottom,0px));pointer-events:none;opacity:0;transform:translateY(14px);transition:opacity .35s ease,transform .35s ease}' +
      '.s3d-feat.on{opacity:1;transform:none}' +
      '.s3d-feat:not(.on){visibility:hidden;transition:opacity .35s ease,transform .35s ease,visibility 0s linear .35s}.s3d-feat:not(.on) button{pointer-events:none!important}' +
      '.s3d-feat button{pointer-events:auto;font-family:"Space Mono",monospace;font-size:14px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;padding:14px 22px;cursor:var(--cur-hand,pointer);border:1.5px solid var(--brass-light,#E9C766);color:#FFF8E6;background:rgba(20,14,9,.88)}' +
      '.s3d-feat button.s3d-primary{background:linear-gradient(180deg,#E3C26A,#B98F33);color:#2A2008;border-color:#F3DC92;font-weight:700;font-size:14px;padding:15px 30px;box-shadow:0 4px 18px rgba(0,0,0,.4)}' +
      '.s3d-feat button:hover{filter:brightness(1.12)}' +
      '.s3d-cap{position:absolute;left:0;right:0;top:0;z-index:3;text-align:center;padding:calc(16px + env(safe-area-inset-top,0px)) 16px 0;pointer-events:none;color:#F6ECD0;font-family:"Space Mono",monospace;font-size:13px;letter-spacing:.1em;text-transform:uppercase;opacity:0;transition:opacity .35s ease;text-shadow:0 1px 6px rgba(0,0,0,.8)}' +
      '.s3d-cap.on{opacity:1}' +
      '.s3d-read button{padding:11px 16px;font-size:13px;font-weight:700}.s3d-read button:disabled{opacity:.35;cursor:default}' +
      '.s3d-read .s3d-pos{align-self:center;color:#FFF8E6;font:13px "Space Mono",monospace;letter-spacing:.08em;min-width:80px;text-align:center;pointer-events:none}.s3d-read .s3d-br{flex-basis:100%;height:0}';
    document.head.appendChild(st);
  }

  /* ---------- texturas ---------- */
  function makeWood(){
    var c = mkCanvas(512, 512), g = c.getContext('2d'), r = rnd(11), i, x;
    var bg = g.createLinearGradient(0, 0, 0, 512);
    bg.addColorStop(0, '#7a4e2c'); bg.addColorStop(0.5, '#6a4325'); bg.addColorStop(1, '#78502e');
    g.fillStyle = bg; g.fillRect(0, 0, 512, 512);
    for(i = 0; i < 30; i++){
      var by = r() * 512, bh = 8 + r() * 46;
      g.fillStyle = r() > 0.5 ? 'rgba(25,10,3,' + (0.04 + r() * 0.08) + ')' : 'rgba(225,170,110,' + (0.03 + r() * 0.07) + ')';
      g.fillRect(0, by, 512, bh);
    }
    for(i = 0; i < 280; i++){
      var y = r() * 512, a = 0.05 + r() * 0.16, dark = r() > 0.45, lw = 0.5 + r() * 1.7;
      var amp = 1 + r() * 4, n = 1 + Math.floor(r() * 3), ph = r() * 6.2832;
      g.strokeStyle = dark ? 'rgba(30,13,4,' + a + ')' : 'rgba(215,160,105,' + a + ')';
      g.lineWidth = lw; g.beginPath();
      for(x = 0; x <= 512; x += 8){ var yy = y + Math.sin(x / 512 * 6.2832 * n + ph) * amp; if(x === 0) g.moveTo(x, yy); else g.lineTo(x, yy); }
      g.stroke();
    }
    for(i = 0; i < 3; i++){
      var cx = 80 + r() * 350, cy = 40 + r() * 430;
      for(var q = 1; q < 6; q++){ g.strokeStyle = 'rgba(35,15,5,' + (0.30 - q * 0.04) + ')'; g.lineWidth = 1.2; g.beginPath(); g.ellipse(cx, cy, q * 7, q * 2.6, 0, 0, 6.3); g.stroke(); }
      g.fillStyle = 'rgba(30,12,4,.35)'; g.beginPath(); g.ellipse(cx, cy, 4, 1.8, 0, 0, 6.3); g.fill();
    }
    var t = tex(c, false, true); t.wrapS = t.wrapT = T.RepeatWrapping; return t;
  }
  function woodMat(rx, ry, tint, rot, rough){
    var t = woodTex.clone(); t.needsUpdate = true; t.repeat.set(rx, ry); t.s3dOwn = true;
    if(rot){ t.center.set(0.5, 0.5); t.rotation = Math.PI / 2; }
    return new T.MeshStandardMaterial({ map:t, bumpMap:t, bumpScale:0.55, roughness:rough || 0.58, metalness:0.03, color:tint || 0xffffff, envMapIntensity:0.5 });
  }
  function makePageTex(){
    var c = mkCanvas(256, 64), g = c.getContext('2d'), r = rnd(5);
    g.fillStyle = '#f0e6cc'; g.fillRect(0, 0, 256, 64);
    for(var x = 0; x < 256; x += 2){ g.fillStyle = 'rgba(110,90,55,' + (0.05 + r() * 0.14) + ')'; g.fillRect(x, 0, 1, 64); }
    for(var k = 0; k < 40; k++){ g.fillStyle = 'rgba(150,120,70,' + (0.05 + r() * 0.08) + ')'; g.fillRect(r() * 256, 0, 2 + r() * 3, 64); }
    var gr = g.createLinearGradient(0, 0, 0, 64); gr.addColorStop(0, 'rgba(0,0,0,.14)'); gr.addColorStop(0.5, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.14)');
    g.fillStyle = gr; g.fillRect(0, 0, 256, 64);
    var t = tex(c, false, true); t.wrapS = t.wrapT = T.RepeatWrapping; return t;
  }
  // couro granulado (a mesma imagem serve de cor e de relevo)
  function makeLeather(){
    var N = 256, c = mkCanvas(N, N), g = c.getContext('2d'), r = rnd(77), i, k;
    g.fillStyle = '#ececec'; g.fillRect(0, 0, N, N);
    function wrap(x, y, rad, fn){
      for(var ox = -1; ox <= 1; ox++) for(var oy = -1; oy <= 1; oy++){
        var X = x + ox * N, Y = y + oy * N; if(X < -rad || X > N + rad || Y < -rad || Y > N + rad) continue; fn(X, Y);
      }
    }
    for(i = 0; i < 1100; i++){
      var x = r() * N, y = r() * N, rad = 1.5 + r() * 3.2, v = 208 + Math.floor(r() * 47);
      wrap(x, y, rad, function(X, Y){ g.fillStyle = 'rgb(' + v + ',' + v + ',' + v + ')'; g.beginPath(); g.arc(X, Y, rad, 0, 6.3); g.fill(); });
    }
    g.lineCap = 'round';
    for(i = 0; i < 900; i++){
      var sx = r() * N, sy = r() * N, ang = r() * 6.3, len = 3 + r() * 7;
      wrap(sx, sy, len, function(X, Y){ g.strokeStyle = 'rgba(90,90,90,' + (0.08 + r() * 0.12) + ')'; g.lineWidth = 0.6 + r() * 0.8; g.beginPath(); g.moveTo(X, Y); g.lineTo(X + Math.cos(ang) * len, Y + Math.sin(ang) * len); g.stroke(); });
    }
    for(k = 0; k < 2500; k++){ g.fillStyle = r() > 0.5 ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.05)'; g.fillRect(r() * N, r() * N, 1, 1); }
    var a = tex(c, false, true), b = tex(c, true, true);
    a.wrapS = a.wrapT = b.wrapS = b.wrapT = T.RepeatWrapping; a.repeat.set(4.2, 4.2); b.repeat.set(4.2, 4.2);
    leatherA = a; leatherB = b;
  }
  // relevo da lombada (igual para todos os livros): cordões, filetes e moldura do título
  function makeSpineBump(){
    var W = 160, H = 640, c = mkCanvas(W, H), g = c.getContext('2d'), r = rnd(91), i;
    g.fillStyle = '#808080'; g.fillRect(0, 0, W, H);
    for(i = 0; i < 2200; i++){ var v = 100 + Math.floor(r() * 60); g.fillStyle = 'rgb(' + v + ',' + v + ',' + v + ')'; g.fillRect(r() * W, r() * H, 1 + r() * 2, 1 + r() * 2); }
    [115, 525].forEach(function(y){
      var gr = g.createLinearGradient(0, y - 11, 0, y + 11); gr.addColorStop(0, '#303030'); gr.addColorStop(0.3, '#ffffff'); gr.addColorStop(0.7, '#ffffff'); gr.addColorStop(1, '#303030');
      g.fillStyle = gr; g.fillRect(0, y - 11, W, 22);
    });
    g.fillStyle = '#e8e8e8'; [[28, 4], [38, 2], [602, 2], [612, 4]].forEach(function(l){ g.fillRect(11, l[0], 138, l[1]); });
    g.strokeStyle = '#f0f0f0'; g.lineWidth = 3; g.strokeRect(25.5, 135.5, 109, 379);
    g.lineWidth = 1.5; g.strokeRect(32, 142, 96, 366);
    spineBump = tex(c, true, true);
  }

  var GOLD_STOPS = [[0, '#7d5c1c'], [0.28, '#f6e2a0'], [0.5, '#c39a38'], [0.74, '#fff1bd'], [1, '#8a6a22']];
  function goldGrad(g, x0, y0, x1, y1){ var gr = g.createLinearGradient(x0, y0, x1, y1); GOLD_STOPS.forEach(function(s){ gr.addColorStop(s[0], s[1]); }); return gr; }

  function spineTexture(b, base, r){
    var W = 160, H = 640, c = mkCanvas(W, H), g = c.getContext('2d'), i;
    var gr = g.createLinearGradient(0, 0, W, 0);
    gr.addColorStop(0, shade(base, -14)); gr.addColorStop(0.5, shade(base, 10)); gr.addColorStop(1, shade(base, -22));
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
    var vg = g.createLinearGradient(0, 0, 0, H);
    vg.addColorStop(0, 'rgba(0,0,0,.30)'); vg.addColorStop(0.08, 'rgba(0,0,0,0)'); vg.addColorStop(0.92, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.34)');
    g.fillStyle = vg; g.fillRect(0, 0, W, H);
    g.globalAlpha = 0.10;                                      // grão do couro
    for(i = 0; i < 1500; i++){ g.fillStyle = r() > 0.5 ? '#000' : '#fff'; g.fillRect(r() * W, r() * H, 1 + r() * 2.2, 1 + r() * 2.2); }
    g.globalAlpha = 1;
    [115, 525].forEach(function(y){                            // cordões em relevo
      var cg = g.createLinearGradient(0, y - 11, 0, y + 11);
      cg.addColorStop(0, 'rgba(0,0,0,.45)'); cg.addColorStop(0.35, 'rgba(255,255,255,.20)'); cg.addColorStop(0.65, 'rgba(255,255,255,.06)'); cg.addColorStop(1, 'rgba(0,0,0,.45)');
      g.fillStyle = cg; g.fillRect(0, y - 11, W, 22);
    });
    var gold = goldGrad(g, 0, 0, W, 0);
    g.fillStyle = gold;
    [[28, 4], [38, 2], [602, 2], [612, 4]].forEach(function(l){ g.fillRect(11, l[0], 138, l[1]); });
    [115, 525].forEach(function(y){ g.fillRect(11, y - 13, 138, 1.6); g.fillRect(11, y + 11, 138, 1.6); });
    g.textAlign = 'center'; g.textBaseline = 'alphabetic';
    g.font = '700 20px "Space Mono", monospace';
    g.fillStyle = 'rgba(0,0,0,.4)'; g.fillText(String(b.no != null ? b.no : '').padStart(3, '0'), 81, 90);
    g.fillStyle = gold; g.fillText(String(b.no != null ? b.no : '').padStart(3, '0'), 80, 88);
    g.fillStyle = 'rgba(0,0,0,.26)'; g.fillRect(25, 135, 110, 380);
    g.strokeStyle = gold; g.lineWidth = 2; g.strokeRect(25.5, 135.5, 109, 379);
    g.strokeStyle = 'rgba(243,220,146,.38)'; g.lineWidth = 1.2; g.strokeRect(32.5, 142.5, 95, 365);
    [150, 500].forEach(function(y){ g.save(); g.translate(80, y); g.rotate(Math.PI / 4); g.fillStyle = gold; g.fillRect(-4, -4, 8, 8); g.restore(); });
    g.save(); g.translate(80, 325); g.rotate(Math.PI / 2);
    var title = String(b.name || ''), size = fitFont(g, title, 330, 50, 22);
    g.font = '700 ' + size + 'px Fraunces, Georgia, serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    var tt = title; while(g.measureText(tt).width > 330 && tt.length > 3) tt = tt.slice(0, -2);
    if(tt !== title) tt = tt.replace(/\s+$/, '') + '…';
    g.fillStyle = 'rgba(0,0,0,.55)'; g.fillText(tt, 2, 2.5);
    g.fillStyle = goldGrad(g, -165, 0, 165, 0); g.fillText(tt, 0, 0);
    g.restore();
    var gc = GRAU_COL[gkey(b.grau)];
    if(gc && b.grau){
      g.save(); g.translate(80, 568); g.rotate(Math.PI / 4);
      g.fillStyle = gc; g.fillRect(-11, -11, 22, 22); g.strokeStyle = gold; g.lineWidth = 2.4; g.strokeRect(-11, -11, 22, 22);
      g.fillStyle = 'rgba(255,255,255,.28)'; g.fillRect(-11, -11, 22, 8);
      g.restore();
    }
    return tex(c);
  }

  /* ---------- capa dourada (só criada quando o livro é pego) ---------- */
  function spaced(g, text, cx, y, sp){
    var w = 0, i; for(i = 0; i < text.length; i++) w += g.measureText(text[i]).width + sp; w -= sp;
    var x = cx - w / 2, prev = g.textAlign; g.textAlign = 'left';
    for(i = 0; i < text.length; i++){ g.fillText(text[i], x, y); x += g.measureText(text[i]).width + sp; }
    g.textAlign = prev;
  }
  function glyph(g, kind, r, F, DK){
    g.save(); g.fillStyle = F; g.strokeStyle = F; g.lineJoin = 'round'; g.lineCap = 'round';
    if(kind === 'arma'){
      [-0.62, 0.62].forEach(function(a){
        g.save(); g.rotate(a);
        g.beginPath(); g.moveTo(0, -r * 0.98); g.lineTo(r * 0.1, -r * 0.72); g.lineTo(r * 0.1, r * 0.2); g.lineTo(-r * 0.1, r * 0.2); g.lineTo(-r * 0.1, -r * 0.72); g.closePath(); g.fill();
        g.fillRect(-r * 0.34, r * 0.2, r * 0.68, r * 0.075); g.fillRect(-r * 0.05, r * 0.27, r * 0.1, r * 0.4);
        g.beginPath(); g.arc(0, r * 0.74, r * 0.085, 0, 6.3); g.fill();
        g.fillStyle = DK; g.fillRect(-r * 0.014, -r * 0.7, r * 0.028, r * 0.84); g.fillStyle = F;
        g.restore();
      });
    } else if(kind === 'consumivel'){
      g.fillRect(-r * 0.13, -r * 0.78, r * 0.26, r * 0.4); g.fillRect(-r * 0.22, -r * 0.86, r * 0.44, r * 0.1);
      g.beginPath(); g.moveTo(-r * 0.13, -r * 0.38); g.lineTo(-r * 0.58, r * 0.34); g.quadraticCurveTo(-r * 0.66, r * 0.86, -r * 0.2, r * 0.86);
      g.lineTo(r * 0.2, r * 0.86); g.quadraticCurveTo(r * 0.66, r * 0.86, r * 0.58, r * 0.34); g.lineTo(r * 0.13, -r * 0.38); g.closePath(); g.fill();
      g.strokeStyle = DK; g.lineWidth = r * 0.07; g.beginPath(); g.moveTo(-r * 0.42, r * 0.16); g.quadraticCurveTo(0, r * 0.3, r * 0.42, r * 0.16); g.stroke();
    } else if(kind === 'utilitario'){
      for(var k = 0; k < 8; k++){ g.save(); g.rotate(k * Math.PI / 4); g.fillRect(-r * 0.13, -r * 0.88, r * 0.26, r * 0.34); g.restore(); }
      g.beginPath(); g.arc(0, 0, r * 0.64, 0, 6.3); g.fill();
      g.fillStyle = DK; g.beginPath(); g.arc(0, 0, r * 0.26, 0, 6.3); g.fill();
    } else if(kind === 'equipamento'){
      var path = function(){
        g.beginPath(); g.moveTo(0, -r * 0.95); g.quadraticCurveTo(r * 0.55, -r * 0.74, r * 0.78, -r * 0.74); g.lineTo(r * 0.78, 0);
        g.quadraticCurveTo(r * 0.7, r * 0.62, 0, r * 1.0); g.quadraticCurveTo(-r * 0.7, r * 0.62, -r * 0.78, 0); g.lineTo(-r * 0.78, -r * 0.74);
        g.quadraticCurveTo(-r * 0.55, -r * 0.74, 0, -r * 0.95); g.closePath();
      };
      path(); g.fill();
      g.save(); g.scale(0.76, 0.76); g.strokeStyle = DK; g.lineWidth = r * 0.07; path(); g.stroke(); g.restore();
      g.fillStyle = DK; g.fillRect(-r * 0.05, -r * 0.55, r * 0.1, r * 1.1); g.fillRect(-r * 0.35, -r * 0.12, r * 0.7, r * 0.1);
    } else {
      g.beginPath(); for(var j = 0; j < 16; j++){ var a = j * Math.PI / 8, rr = j % 2 ? r * 0.38 : r * 0.9; g.lineTo(Math.sin(a) * rr, -Math.cos(a) * rr); } g.closePath(); g.fill();
    }
    g.restore();
  }
  function drawCover(g, cw, ch, d, mode){
    var bump = mode === 'bump', u = cw / 512, i;
    var DK = bump ? '#000' : 'rgba(45,28,6,.9)';
    var F = function(x0, y0, x1, y1){ return bump ? '#fff' : goldGrad(g, x0, y0, x1, y1); };
    if(bump){ g.fillStyle = '#555'; g.fillRect(0, 0, cw, ch); } else g.clearRect(0, 0, cw, ch);
    var x0 = 70 * u, x1 = cw - 30 * u, y0 = 34 * u, y1 = ch - 34 * u, cx = (x0 + x1) / 2;
    g.lineJoin = 'miter';
    g.strokeStyle = F(x0, y0, x1, y1); g.lineWidth = 4.5 * u; g.strokeRect(x0, y0, x1 - x0, y1 - y0);
    g.lineWidth = 1.6 * u; g.strokeRect(x0 + 12 * u, y0 + 12 * u, x1 - x0 - 24 * u, y1 - y0 - 24 * u);
    // cantoneiras desenhadas
    [[x0 + 12 * u, y0 + 12 * u, 1, 1], [x1 - 12 * u, y0 + 12 * u, -1, 1], [x0 + 12 * u, y1 - 12 * u, 1, -1], [x1 - 12 * u, y1 - 12 * u, -1, -1]].forEach(function(p){
      g.save(); g.translate(p[0], p[1]); g.scale(p[2], p[3]); g.strokeStyle = F(0, 0, 60 * u, 60 * u); g.fillStyle = g.strokeStyle; g.lineWidth = 2.2 * u;
      g.beginPath(); g.arc(0, 0, 26 * u, 0, Math.PI / 2); g.stroke(); g.beginPath(); g.arc(0, 0, 16 * u, 0, Math.PI / 2); g.stroke();
      g.beginPath(); g.arc(30 * u, 30 * u, 4 * u, 0, 6.3); g.fill(); g.restore();
    });
    // categoria no alto
    var cat = String(d.cat || '').toUpperCase();
    g.fillStyle = F(x0, 0, x1, 0); g.textBaseline = 'middle'; g.textAlign = 'center';
    g.font = '700 ' + (17 * u) + 'px "Space Mono", monospace'; if(cat) spaced(g, cat, cx, y0 + 46 * u, 5 * u);
    g.fillRect(cx - 60 * u, y0 + 66 * u, 120 * u, 1.6 * u);
    // medalhão
    var my = ch * 0.37, R = cw * 0.205;
    g.strokeStyle = F(cx - R, my - R, cx + R, my + R); g.lineWidth = 4 * u; g.beginPath(); g.arc(cx, my, R, 0, 6.3); g.stroke();
    g.lineWidth = 1.6 * u; g.beginPath(); g.arc(cx, my, R * 0.9, 0, 6.3); g.stroke();
    g.fillStyle = g.strokeStyle; for(i = 0; i < 36; i++){ var a = i / 36 * 6.2832; g.beginPath(); g.arc(cx + Math.cos(a) * R * 1.14, my + Math.sin(a) * R * 1.14, 2.2 * u, 0, 6.3); g.fill(); }
    if(!bump){ g.fillStyle = 'rgba(0,0,0,.30)'; g.beginPath(); g.arc(cx, my, R * 0.88, 0, 6.3); g.fill(); }
    g.save(); g.translate(cx, my); glyph(g, d.catId, R * 0.62, F(-R, -R, R, R), DK); g.restore();
    // título
    var words = String(d.name || '').split(/\s+/), size = 46 * u, lines, ty;
    for(;;){
      g.font = '700 ' + size + 'px Fraunces, Georgia, serif'; lines = []; var cur = '';
      words.forEach(function(w){ var t = cur ? cur + ' ' + w : w; if(g.measureText(t).width > (x1 - x0 - 50 * u) && cur){ lines.push(cur); cur = w; } else cur = t; });
      if(cur) lines.push(cur);
      if((lines.length <= 3 && size >= 24 * u) || size <= 22 * u) break; size -= 3 * u;
    }
    lines = lines.slice(0, 4); var lh = size * 1.18; ty = ch * 0.66 + size * 0.2 - (lines.length - 1) * lh / 2 + lh * 0.4;
    lines.forEach(function(l, k){
      if(!bump){ g.fillStyle = 'rgba(0,0,0,.55)'; g.fillText(l, cx + 1.5 * u, ty + k * lh + 2 * u); }
      g.fillStyle = F(cx - 140 * u, 0, cx + 140 * u, 0); g.fillText(l, cx, ty + k * lh);
    });
    // divisor e grau
    var dy = ch * 0.83;
    g.fillStyle = F(x0, 0, x1, 0); g.fillRect(cx - 90 * u, dy, 76 * u, 1.8 * u); g.fillRect(cx + 14 * u, dy, 76 * u, 1.8 * u);
    g.save(); g.translate(cx, dy + 0.9 * u); g.rotate(Math.PI / 4); g.fillRect(-6 * u, -6 * u, 12 * u, 12 * u); g.restore();
    g.font = '700 ' + (17 * u) + 'px "Space Mono", monospace';
    var gt = d.grau ? (GRAU_TXT[gkey(d.grau)] || '').toUpperCase() : '';
    if(gt) spaced(g, gt, cx, dy + 30 * u, 4 * u);
    g.font = '700 ' + (14 * u) + 'px "Space Mono", monospace';
    spaced(g, 'Nº ' + String(d.no != null ? d.no : '').padStart(3, '0'), cx, y1 - 30 * u, 4 * u);
    // vinco da dobradiça
    if(bump){ g.fillStyle = '#000'; g.fillRect(0.085 * cw, 0, 5 * u, ch); g.fillStyle = '#ccc'; g.fillRect(0.085 * cw + 7 * u, 0, 3 * u, ch); }
    else {
      var hg = g.createLinearGradient(0, 0, cw * 0.12, 0);
      hg.addColorStop(0, 'rgba(0,0,0,.55)'); hg.addColorStop(0.7, 'rgba(0,0,0,.18)'); hg.addColorStop(0.74, 'rgba(0,0,0,.45)'); hg.addColorStop(0.8, 'rgba(255,255,255,.06)'); hg.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = hg; g.fillRect(0, 0, cw * 0.12, ch);
    }
  }

  /* ---------- placas da estante ---------- */
  function floorPlate(text, col){
    var c = mkCanvas(512, 80), g = c.getContext('2d');
    var gr = g.createLinearGradient(0, 0, 0, 80); gr.addColorStop(0, '#F3DC92'); gr.addColorStop(0.5, '#C9A13E'); gr.addColorStop(1, '#8F6E1F');
    g.fillStyle = gr; g.fillRect(0, 0, 512, 80);
    g.strokeStyle = 'rgba(60,40,5,.75)'; g.lineWidth = 3; g.strokeRect(4, 4, 504, 72);
    g.strokeStyle = 'rgba(255,240,190,.6)'; g.lineWidth = 1; g.strokeRect(9, 9, 494, 62);
    g.save(); g.translate(44, 40); g.rotate(Math.PI / 4); g.fillStyle = col; g.fillRect(-13, -13, 26, 26); g.strokeStyle = '#3a2808'; g.lineWidth = 2.5; g.strokeRect(-13, -13, 26, 26); g.restore();
    g.fillStyle = '#2A2008'; g.textAlign = 'left'; g.textBaseline = 'middle';
    var s = fitFont(g, text.toUpperCase(), 400, 42, 16); g.font = '700 ' + s + 'px "Space Mono", monospace'; g.fillText(text.toUpperCase(), 80, 42);
    return tex(c);
  }
  function headerPlate(text, count){
    var c = mkCanvas(1024, 160), g = c.getContext('2d');
    var gr = g.createLinearGradient(0, 0, 0, 160); gr.addColorStop(0, '#F3DC92'); gr.addColorStop(0.45, '#C9A13E'); gr.addColorStop(1, '#8F6E1F');
    g.fillStyle = gr; g.fillRect(0, 0, 1024, 160);
    g.strokeStyle = 'rgba(60,40,5,.8)'; g.lineWidth = 5; g.strokeRect(6, 6, 1012, 148);
    g.strokeStyle = 'rgba(255,240,190,.65)'; g.lineWidth = 1.6; g.strokeRect(16, 16, 992, 128);
    g.fillStyle = '#2A2008'; g.textAlign = 'center'; g.textBaseline = 'middle';
    var s = fitFont(g, text.toUpperCase(), 760, 84, 28); g.font = '700 ' + s + 'px Fraunces, Georgia, serif';
    g.fillStyle = 'rgba(255,240,190,.5)'; g.fillText(text.toUpperCase(), 513, 83);
    g.fillStyle = '#2A2008'; g.fillText(text.toUpperCase(), 512, 80);
    [70, 954].forEach(function(x){ g.save(); g.translate(x, 80); g.rotate(Math.PI / 4); g.fillStyle = '#2A2008'; g.fillRect(-12, -12, 24, 24); g.restore(); });
    g.font = '700 22px "Space Mono", monospace'; g.fillStyle = 'rgba(42,32,8,.8)'; g.fillText(String(count) + (count === 1 ? ' ITEM' : ' ITENS'), 512, 134);
    return tex(c);
  }

  /* ---------- ambiente (reflexos suaves no couro e no ouro) ---------- */
  function makeEnv(){
    try{
      var pm = new T.PMREMGenerator(renderer), es = new T.Scene();
      var geo = new T.SphereGeometry(20, 48, 24), pos = geo.attributes.position, col = new Float32Array(pos.count * 3), i;
      for(i = 0; i < pos.count; i++){
        var y = pos.getY(i) / 20, r, g, b;
        if(y > 0){ r = 0.34 + 0.30 * y; g = 0.30 + 0.27 * y; b = 0.23 + 0.20 * y; } else { r = 0.13 + 0.10 * (1 + y); g = 0.09 + 0.07 * (1 + y); b = 0.06 + 0.04 * (1 + y); }
        col[i * 3] = r; col[i * 3 + 1] = g; col[i * 3 + 2] = b;
      }
      geo.setAttribute('color', new T.BufferAttribute(col, 3));
      es.add(new T.Mesh(geo, new T.MeshBasicMaterial({ vertexColors:true, side:T.BackSide })));
      [[-12, 10, 14, 1.7], [13, 5, 11, 0.9], [0, 15, -4, 1.1]].forEach(function(s){
        var m = new T.Mesh(new T.PlaneGeometry(11, 6), new T.MeshBasicMaterial({ color:new T.Color(s[3], s[3] * 0.94, s[3] * 0.82), side:T.DoubleSide }));
        m.position.set(s[0], s[1], s[2]); m.lookAt(0, 0, 0); es.add(m);
      });
      scene.environment = pm.fromScene(es, 0.04).texture; pm.dispose(); envOn = true;
      geo.dispose();
    }catch(e){ envOn = false; }
  }

  /* ---------- materiais compartilhados ---------- */
  function lin(hex){ return new T.Color(hex).convertSRGBToLinear(); }
  function leatherMat(col, gloss){
    var key = 'L' + col + gloss; if(matCache[key]) return matCache[key];
    return matCache[key] = new T.MeshStandardMaterial({ color:lin(col), map:leatherA, bumpMap:leatherB, bumpScale:0.1, roughness:gloss ? 0.62 : 0.78, metalness:0, envMapIntensity:gloss ? 0.3 : 0.16 });
  }
  function edgeMat(col){
    var key = 'E' + col; if(matCache[key]) return matCache[key];
    return matCache[key] = new T.MeshStandardMaterial({ color:lin(shade(col, -10)), map:leatherA, bumpMap:leatherB, bumpScale:0.1, roughness:0.85, metalness:0, envMapIntensity:0.12 });
  }
  function sharedMat(name){
    if(matCache[name]) return matCache[name];
    if(name === 'page') return matCache[name] = new T.MeshStandardMaterial({ map:pageTex, roughness:0.95, envMapIntensity:0.25 });
    if(name === 'gild') return matCache[name] = new T.MeshStandardMaterial({ color:0xe2b954, map:pageTex, metalness:0.72, roughness:0.3, envMapIntensity:1.2 });
    if(name === 'corner') return matCache[name] = new T.MeshStandardMaterial({ color:0x9c7226, metalness:0.8, roughness:0.38, envMapIntensity:0.9 });
    if(name === 'pageTop') return matCache[name] = new T.MeshStandardMaterial({ map:pageTex, roughness:0.9, color:0xe8dcc0, envMapIntensity:0.25 });
  }

  /* ---------- geometria do livro ---------- */
  function boardGeo(lb, h, ct){
    var bt = Math.min(0.012, ct * 0.22), rr = 0.045, w2 = lb / 2, h2 = h / 2;
    var sh = new T.Shape();
    sh.moveTo(-w2 + rr, -h2); sh.lineTo(w2 - rr, -h2); sh.quadraticCurveTo(w2, -h2, w2, -h2 + rr); sh.lineTo(w2, h2 - rr); sh.quadraticCurveTo(w2, h2, w2 - rr, h2);
    sh.lineTo(-w2 + rr, h2); sh.quadraticCurveTo(-w2, h2, -w2, h2 - rr); sh.lineTo(-w2, -h2 + rr); sh.quadraticCurveTo(-w2, -h2, -w2 + rr, -h2);
    var g = new T.ExtrudeGeometry(sh, { depth:ct - 2 * bt, bevelEnabled:true, bevelThickness:bt, bevelSize:bt, bevelSegments:2, curveSegments:4 });
    g.translate(0, 0, -(ct - 2 * bt) / 2);       // centra a espessura
    g.rotateY(Math.PI / 2);                      // espessura → eixo x; comprimento → eixo z
    return g;
  }
  function spineParts(th, h, dp, s, spineM, capM){
    var R = (th * th / 4 + s * s) / (2 * s), ang = 2 * Math.asin(Math.min(1, th / 2 / R)), cz = dp / 2 - R, out = [];
    var cyl = new T.CylinderGeometry(R, R, h, 20, 1, true, -ang / 2, ang);
    var m = new T.Mesh(cyl, spineM); m.position.set(0, 0, cz); out.push(m);
    var pts = [], k; for(k = 0; k <= 12; k++){ var t = -ang / 2 + ang * k / 12; pts.push(new T.Vector2(R * Math.sin(t), -(cz + R * Math.cos(t)))); }
    var cg = new T.ShapeGeometry(new T.Shape(pts)); cg.rotateX(-Math.PI / 2);
    var top = new T.Mesh(cg, capM); top.position.y = h / 2; out.push(top);
    var bot = new T.Mesh(cg, capM); bot.position.y = -h / 2; bot.scale.y = -1; out.push(bot);
    return out;
  }
  function makeBook(bk, d, baseCol, gloss, r, ci, bi){
    var th = bk.th, h = bk.h, dp = bk.dp, ct = Math.min(0.055, th * 0.16), s = 0.05, lb = dp - s;
    var cm = leatherMat(baseCol, gloss), em = edgeMat(baseCol);
    var spineM = new T.MeshStandardMaterial({ map:spineTexture(d, baseCol, r), bumpMap:spineBump, bumpScale:1.1, roughness:gloss ? 0.46 : 0.6, metalness:0.05, envMapIntensity:0.55 });
    var g = new T.Group(), bg = boardGeo(lb, h, ct);
    function add(mesh){ mesh.castShadow = true; mesh.receiveShadow = true; g.add(mesh); return mesh; }
    var front = add(new T.Mesh(bg, [cm, em])); front.position.set(th / 2 - ct / 2, 0, -s / 2);
    var back = add(new T.Mesh(bg, [cm, em])); back.rotation.y = Math.PI; back.position.set(-(th / 2 - ct / 2), 0, -s / 2);
    spineParts(th, h, dp, s, spineM, em).forEach(add);
    var pz0 = -dp / 2 + 0.035, pz1 = dp / 2 - s + 0.012, pm = sharedMat(gloss ? 'gild' : 'page'), pt = gloss ? sharedMat('gild') : sharedMat('pageTop');
    var pages = add(new T.Mesh(new T.BoxGeometry(th - 2 * ct + 0.004, h - 0.07, pz1 - pz0), [pm, pm, pt, pt, pm, pm]));
    pages.position.set(0, 0, (pz0 + pz1) / 2); pages.castShadow = false;
    g.userData = { ct:ct, s:s, lb:lb };
    return g;
  }
  // detalhes que só aparecem de perto: capa dourada em relevo, cantoneiras de metal
  function decorate(b){
    if(b.decorated) return; b.decorated = true;
    var th = b.th, h = b.h, dp = b.dp, ct = b.mesh.userData.ct, s = b.mesh.userData.s, lb = b.mesh.userData.lb, g = b.mesh;
    var cw = 512, ch = Math.round(cw * h / lb), foil = mkCanvas(cw, ch), bump = mkCanvas(cw, ch);
    drawCover(foil.getContext('2d'), cw, ch, b.data, 'foil'); drawCover(bump.getContext('2d'), cw, ch, b.data, 'bump');
    var dm = new T.MeshStandardMaterial({ map:tex(foil), bumpMap:tex(bump, true), bumpScale:2.6, transparent:true, roughness:0.3, metalness:0.5, envMapIntensity:1.1, depthWrite:false, polygonOffset:true, polygonOffsetFactor:-2, polygonOffsetUnits:-2 });
    var dec = new T.Mesh(new T.PlaneGeometry(lb - 0.02, h - 0.02), dm);
    dec.rotation.y = Math.PI / 2; dec.position.set(th / 2 + 0.0025, 0, -s / 2); g.add(dec);
    var a = 0.15, tg = new T.Shape(); tg.moveTo(0, 0); tg.lineTo(a, 0); tg.lineTo(0, a); tg.closePath();
    var cg = new T.ExtrudeGeometry(tg, { depth:ct + 0.004, bevelEnabled:true, bevelThickness:0.004, bevelSize:0.004, bevelSegments:1 });
    cg.translate(0, 0, -(ct + 0.004) / 2); cg.rotateY(Math.PI / 2);
    var cm = sharedMat('corner');
    [[1, -1], [1, 1], [-1, -1], [-1, 1]].forEach(function(p){      // [lado(x), alto(y)] — só na beira de fora
      var m = new T.Mesh(cg, cm); m.castShadow = true;
      m.position.set(p[0] * (th / 2 - ct / 2), p[1] * h / 2, -dp / 2);
      m.scale.set(1, -p[1], -1); g.add(m);
    });
    b.extras = [dec];
  }

  /* ---------- montagem das estantes ---------- */
  function disposeCase(c){
    if(!c.group) return;
    root.remove(c.group);
    c.group.traverse(function(o){
      if(o.geometry) o.geometry.dispose();
      if(o.material){ (Array.isArray(o.material) ? o.material : [o.material]).forEach(function(m){
        if(m.map && m.map.s3dOwn) m.map.dispose();
        if(m.bumpMap && m.bumpMap.s3dOwn && m.bumpMap !== m.map) m.bumpMap.dispose();
        m.dispose();
      }); }
    });
    c.group = null;
  }
  function disposeAll(){
    buildToken++;
    cases.forEach(disposeCase);
    Object.keys(matCache).forEach(function(k){ matCache[k].dispose(); });
    matCache = {}; cases = []; hovered = null; hoverShelf = -1;
  }
  function box(w, h, d, mat, x, y, z){
    var m = new T.Mesh(new T.BoxGeometry(w, h, d), mat); m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; return m;
  }

  function layoutLevels(row, W){
    var byG = {};
    row.books.forEach(function(b){ var k = gkey(b.grau); if(!GRAU_COL[k]) k = ''; (byG[k] = byG[k] || []).push(b); });
    var levels = [];
    FLOORS.forEach(function(k){
      var list = byG[k] || [];
      if(!list.length && (k === 'calamidade' || k === '')){ return; }       // esses andares só existem se houver livros
      if(!list.length){ levels.push({ key:k, part:0, books:[] }); return; }
      var cur = null, used = 0, part = 0;
      list.forEach(function(b){
        var r = rnd(hash(String(b.id)));
        var th = 0.26 + r() * 0.2 + Math.min(String(b.name || '').length, 40) * 0.002;
        var h = 1.3 + r() * 0.4, dp = h * (0.66 + r() * 0.08);
        if(!cur || used + th > W - 0.9){ cur = { key:k, part:part++, books:[] }; levels.push(cur); used = 0; }
        cur.books.push({ data:b, th:th, h:h, dp:dp, seed:hash(String(b.id) + 'x') }); used += th + 0.02;
      });
    });
    return levels;
  }

  function buildStruct(c){
    var W = c.W, R = c.levels.length, Ht = c.Ht, st = new T.Group();
    var sideM = woodMat(Math.max(1, Ht / 7), 0.35, 0xdcc5ae, true);
    var trimM = woodMat(Math.max(1, Ht / 7), 0.2, 0xffffff, true);
    var shelfM = woodMat(Math.max(1, W / 5), 0.3, 0xdcc5ae);
    var fasciaM = woodMat(Math.max(1, W / 5), 0.12, 0xffffff);
    var topM = woodMat(Math.max(1, W / 5), 0.3, 0xffffff);
    var baseM = woodMat(Math.max(1, W / 5), 0.3, 0xb89a80);
    var i;
    // sem painel de fundo: a estante é aberta atrás (só laterais, prateleiras e frontão)
    [-1, 1].forEach(function(sg){
      var sx = sg * (W / 2 + 0.25);
      st.add(box(0.5, Ht, D, sideM, sx, Ht / 2, 0));
      st.add(box(0.64, Ht, 0.07, trimM, sx, Ht / 2, D / 2 + 0.035));
    });
    for(i = 0; i <= R; i++){
      st.add(box(W, BT, D, shelfM, 0, i * LH + BT / 2, 0));
      st.add(box(W + 0.02, BT + 0.06, 0.06, fasciaM, 0, i * LH + BT / 2, D / 2 + 0.03));
    }
    st.add(box(W + 1.2, 0.14, D + 0.2, baseM, 0, Ht + 0.07, 0.05));
    st.add(box(W + 1.7, 0.26, D + 0.4, topM, 0, Ht + 0.27, 0.1));
    st.add(box(W + 1.2, 0.42, D + 0.2, baseM, 0, -0.21, 0.05));
    st.add(box(W + 1.5, 0.16, D + 0.4, topM, 0, -0.5, 0.1));
    // frontão com o nome da estante
    var hd = D * 0.62, hz = -D / 2 + 0.05 + hd / 2;
    st.add(box(W + 1.0, 1.0, hd, baseM, 0, Ht + 0.9, hz));
    st.add(box(W + 1.3, 0.12, hd + 0.12, topM, 0, Ht + 1.46, hz));
    var plate = new T.Mesh(new T.PlaneGeometry(Math.min(W * 0.62, 6.4), 0.62), new T.MeshStandardMaterial({ map:headerPlate(c.label, c.count), roughness:0.28, metalness:0.55, envMapIntensity:1.0 }));
    plate.position.set(0, Ht + 0.9, hz + hd / 2 + 0.006); st.add(plate);
    // placas dos andares
    c.plates = [];
    c.levels.forEach(function(lv, li){
      var base = (R - 1 - li) * LH + BT, label = GRAU_PLATE[lv.key] + (lv.part ? ' · ' + (lv.part + 1) : '');
      var pw = Math.min(3.0, W * 0.4);
      var pl = new T.Mesh(new T.PlaneGeometry(pw, pw * 80 / 512), new T.MeshStandardMaterial({ map:floorPlate(label, GRAU_COL[lv.key]), roughness:0.3, metalness:0.5, envMapIntensity:0.9 }));
      pl.position.set(-W / 2 + pw / 2 + 0.2, base - BT / 2, D / 2 + 0.065); st.add(pl); c.plates.push(pl);
    });
    st.traverse(function(o){ o.userData.ci = c.index; o.userData.struct = true; });
    c.struct = st; c.group.add(st);
  }

  function ensureBooks(c){
    if(c.booksBuilt || !c.group) return; c.booksBuilt = true;
    var W = c.W, R = c.levels.length, booksG = new T.Group(); c.booksG = booksG; c.group.add(booksG);
    c.levels.forEach(function(lv, li){
      var base = (R - 1 - li) * LH + BT, x = -W / 2 + 0.25;
      lv.books.forEach(function(bk, bi){
        var d = bk.data, r = rnd(bk.seed), gk = gkey(d.grau);
        var baseCol = (d.grau && GRAU_BASE[gk] && r() > 0.25) ? GRAU_BASE[gk] : PALETTE[hash(String(d.id)) % PALETTE.length];
        var gloss = GLOSSY[gk] ? 1 : 0;
        var dd = { id:d.id, name:d.name, grau:d.grau, no:d.no, cat:c.label, catId:c.id, image:d.image, content:d.content, created:d.created };
        var m = makeBook(bk, dd, baseCol, gloss, r, c.index, c.books.length);
        var lean = (bi === lv.books.length - 1 && r() > 0.5) ? 0.12 : (r() > 0.88 ? (r() - 0.5) * 0.08 : 0);
        var px = x + bk.th / 2 + (lean ? bk.h * Math.sin(Math.abs(lean)) / 2 : 0);
        var pz = D / 2 - bk.dp / 2 - 0.05 - r() * 0.06;
        m.position.set(px, base + bk.h / 2, pz); m.rotation.z = -lean;
        var idx = c.books.length;
        m.traverse(function(o){ o.userData.ci = c.index; o.userData.bi = idx; });
        booksG.add(m);
        c.books.push({ mesh:m, id:d.id, data:dd, baseCol:baseCol, x:px, y:base + bk.h / 2, z:pz, rz:-lean, q0:new T.Quaternion().setFromAxisAngle(new T.Vector3(0, 0, 1), -lean), th:bk.th, h:bk.h, dp:bk.dp, hv:0, feat:0, tgtFeat:0, decorated:false, extras:null });
        x += bk.th + 0.02 + (r() > 0.93 ? 0.12 : 0);
      });
    });
    booksG.visible = Math.abs(c.rk) < 2.6;
  }
  function queueBuilds(){
    var tok = buildToken;
    var next = null; for(var i = 0; i < cases.length; i++) if(!cases[i].booksBuilt){ next = cases[i]; break; }
    if(!next) return;
    setTimeout(function(){ if(tok !== buildToken) return; ensureBooks(next); queueBuilds(); }, 280);
  }

  function build(){
    disposeAll();
    if(msgEl) msgEl.hidden = true;
    var small = (window.innerWidth || 600) < 560;
    var W = small ? 6.4 : 9.6, n = lastData.length, total = 0;
    lastData.forEach(function(r){ total += (r.books || []).length; });
    if(!n || !total){
      if(msgEl){ msgEl.textContent = 'Nenhum item encontrado.'; msgEl.hidden = false; }
    }
    var si = 0;
    lastData.forEach(function(r, i){ if(selId !== null && r.id === selId) si = i; });
    if(selId === null || !lastData.some(function(r){ return r.id === selId; })){
      si = 0; for(var q = 0; q < n; q++) if((lastData[q].books || []).length){ si = q; break; }
    }
    selIdx = Math.min(si, Math.max(0, n - 1)); selId = n ? lastData[selIdx].id : null;
    lastData.forEach(function(r, i){
      var row = { id:r.id, label:r.label, books:r.books || [] };
      var c = { index:i, id:r.id, label:r.label, count:row.books.length, W:W, books:[], booksBuilt:false, rk:0 };
      c.levels = layoutLevels(row, W);
      c.Ht = c.levels.length * LH + BT;
      c.group = new T.Group(); root.add(c.group);
      c.rk = i - selIdx;
      buildStruct(c);
      cases.push(c);
    });
    cases.forEach(placeCase);
    if(cases[selIdx]) ensureBooks(cases[selIdx]);
    setTargets(true);
    renderTabs();
    // luz e sombra cobrindo todas as estantes
    var maxTop = 0, i2; cases.forEach(function(c){ maxTop = Math.max(maxTop, c.Ht + 1.4); });
    var spread = n > 1 ? 7 : 0, rad = Math.max(W + 2, maxTop) * 0.62 + 4 + spread, sc = sun.shadow.camera;
    sun.target.position.set(0, maxTop * 0.45, -2);
    sun.position.set(-9, maxTop * 0.45 + 8 + maxTop * 0.1, 18);
    sc.left = -rad; sc.right = rad; sc.top = rad; sc.bottom = -rad; sc.near = 1; sc.far = 140; sc.updateProjectionMatrix();
    sizeHost(); updateCamera(true); renderOnce(); queueBuilds();
  }
  // posição de cada estante pelo deslocamento relativo à escolhida (rk: 0 = de frente no centro, ±1 = vizinha, ...)
  function placeCase(c){
    var a = Math.abs(c.rk), sg = c.rk < 0 ? -1 : 1, q = Math.min(a, 1), ex = Math.max(0, a - 1), e = q * q * (3 - 2 * q);
    var x1 = c.W / 2 + 4.6, z1 = c.W * 0.45;
    c.group.position.set(sg * (q * x1 + ex * GX), 0, -(q * z1 + ex * ZG));
    c.group.rotation.y = -sg * SIDE_ANG * e;
    var vis = a < 2.6;
    if(c.booksG) c.booksG.visible = vis;
    c.group.visible = a < 3.6;
  }
  function setTargets(snap){
    var c = cases[selIdx]; if(!c) return;
    tgtW = c.W + 1.7 + (cases.length > 1 ? 3.2 : 0); tgtTop = c.Ht + 1.4;
    if(snap){ fitW = tgtW; fitTop = tgtTop; }
  }

  function renderTabs(){
    if(!tabsEl) return;
    tabsEl.innerHTML = '';
    cases.forEach(function(c, i){
      var b = document.createElement('button'); b.type = 'button'; b.className = 's3d-tab' + (i === selIdx ? ' on' : '');
      var s1 = document.createElement('span'), s2 = document.createElement('small'); s1.textContent = c.label; s2.textContent = c.count;
      b.appendChild(s1); b.appendChild(s2);
      b.addEventListener('click', function(){ select(i); });
      tabsEl.appendChild(b);
    });
    tabsEl.hidden = cases.length < 2;
  }
  function select(i){
    if(featBook || i === selIdx || !cases[i]) return;
    selIdx = i; selId = cases[i].id; hovered = null; hoverShelf = -1; setTip(null);
    ensureBooks(cases[i]); setTargets(false);
    if(tabsEl) Array.prototype.forEach.call(tabsEl.children, function(el, k){ el.classList.toggle('on', k === i); });
    renderOnce();
  }

  /* ---------- tamanho e câmera ---------- */
  function sizeHost(){
    var w = host.clientWidth || 600, n = cases.length, top = 14;
    cases.forEach(function(c){ top = Math.max(top, c.Ht + 1.4); });
    var wf = (cases[0] ? cases[0].W : 9.6) + 1.7 + (n > 1 ? 3.2 : 0);
    var ratio = (top - YB) / wf;
    var maxPx = Math.max(520, (window.innerHeight || 800) * 0.9);
    var px = Math.round(Math.max(460, Math.min(maxPx, w * ratio * 1.02)));
    canvasHost.style.height = (full ? (window.innerHeight || px) : px) + 'px';
    resize();
  }
  function resize(){
    if(!renderer) return;
    var w = canvasHost.clientWidth, h = canvasHost.clientHeight;
    if(!w || !h) return;
    renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
    renderer.domElement.style.width = '100%'; renderer.domElement.style.height = '100%';
  }
  function updateCamera(){
    var w = canvasHost.clientWidth || 600, h = canvasHost.clientHeight || 400, a = w / h, t = Math.tan(camera.fov * Math.PI / 360) * 0.86;
    // com várias estantes, abre espaço lateral para as vizinhas (viradas de lado) não ficarem cortadas; em telas estreitas (celular) mantém o enquadramento antigo
    var sideEx = cases.length > 1 ? 11.5 * Math.max(0, Math.min(1, (a - 0.9) / 0.9)) : 0;
    var d1 = (fitTop - YB) / (2 * t), dW = ((fitW + sideEx) / 2 * 1.03) / (t * a);
    var d = Math.max(d1, dW) / zoom + 0.6, ty = (fitTop + YB) / 2;
    camera.position.set(0, ty + Math.sin(pitch) * d, Math.cos(pitch) * d);
    camera.lookAt(0, ty, 0);
    if(scene.fog){ scene.fog.near = d + 10; scene.fog.far = d + 90; }
  }

  /* ---------- interação ---------- */
  function pick(ev){
    var r = renderer.domElement.getBoundingClientRect();
    mouse.x = ((ev.clientX - r.left) / r.width) * 2 - 1; mouse.y = -((ev.clientY - r.top) / r.height) * 2 + 1;
    ray.setFromCamera(mouse, camera);
    var list = [], sc = cases[selIdx];
    if(sc){ if(sc.booksG && sc.booksG.visible) sc.books.forEach(function(b){ list.push(b.mesh); }); if(sc.struct) list.push(sc.struct); }
    cases.forEach(function(c, i){ if(i === selIdx || !c.group.visible) return; if(c.struct) list.push(c.struct); if(c.booksG && c.booksG.visible) list.push(c.booksG); });
    var hits = ray.intersectObjects(list, true);
    for(var k = 0; k < hits.length; k++){
      var u = hits[k].object.userData;
      if(u.ci === undefined) continue;
      if(u.bi !== undefined && u.ci === selIdx) return { book:cases[u.ci].books[u.bi] };
      if(u.ci !== selIdx) return { shelf:u.ci };
      return null;                                    // bateu na própria estante da frente
    }
    return null;
  }
  function setTip(txt, ev){
    if(!tipEl) return;
    if(!txt){ tipEl.hidden = true; return; }
    tipEl.textContent = txt;
    var r = host.getBoundingClientRect(); tipEl.style.left = Math.min(r.width - 10, Math.max(10, ev.clientX - r.left + 14)) + 'px'; tipEl.style.top = Math.max(8, ev.clientY - r.top - 34) + 'px';
    tipEl.hidden = false;
  }
  function onDown(ev){
    drag = { x:ev.clientX, y:ev.clientY, yaw0:yaw, fy0:featYaw, ft0:featTilt, moved:false };
    yawVel = 0;
    try{ renderer.domElement.setPointerCapture(ev.pointerId); }catch(e){}
  }
  function onMove(ev){
    if(drag){
      var dx = ev.clientX - drag.x, dy = ev.clientY - drag.y;
      if(Math.abs(dx) > 6 || Math.abs(dy) > 6) drag.moved = true;
      if(drag.moved){
        if(featBook){
          featYaw = drag.fy0 + dx * 0.012; featTilt = Math.max(-0.7, Math.min(0.7, drag.ft0 + dy * 0.006));
        } else {
          var ny = drag.yaw0 + dx * 0.006; yawVel = (ny - yaw); yaw = Math.max(-0.6, Math.min(0.6, ny));
          if(ev.pointerType === 'mouse'){ pitch = Math.max(-0.05, Math.min(0.3, pitch + dy * 0.0006)); }
        }
        setTip(null);
      }
      return;
    }
    if(ev.pointerType === 'mouse' && !featBook){
      var p = pick(ev), b = p && p.book ? p.book : null, sh = p && p.shelf !== undefined ? p.shelf : -1;
      if(b !== hovered){ hovered = b; }
      hoverShelf = sh;
      renderer.domElement.style.cursor = (b || sh >= 0) ? 'var(--cur-hand,pointer)' : 'var(--cur-grab,grab)';
      setTip(b ? b.data.name + (b.data.grau ? ' · ' + GRAU_TXT[gkey(b.data.grau)] : '') : (sh >= 0 ? cases[sh].label + ' · ' + cases[sh].count : null), ev);
    }
  }
  function onUp(ev){
    if(!drag) return;
    var d = drag; drag = null;
    try{ renderer.domElement.releasePointerCapture(ev.pointerId); }catch(e){}
    if(d.moved) return;
    if(featBook){
      if(featBook.tgtOpen && featBook.openP >= 1){ var rc = renderer.domElement.getBoundingClientRect(); flipBy(ev.clientX > rc.left + rc.width * (openSingle() ? 0.4 : 0.5) ? 1 : -1); return; }   // livro aberto: toque vira a página
      var p0 = pick(ev); if(!p0 || !p0.book) back();      // toque fora do livro: volta para a estante
      return;
    }
    var p = pick(ev);
    if(p && p.book) feature(p.book); else if(p && p.shelf !== undefined) select(p.shelf);
  }
  function onLeave(){ hovered = null; hoverShelf = -1; setTip(null); }

  function enterFull(){
    if(full) return; full = true;
    hostPrevH = host.style.height; host.style.height = host.offsetHeight + 'px';       // guarda o espaço na página
    fullPrev = document.documentElement.style.overflow; document.documentElement.style.overflow = 'hidden';
    canvasHost.classList.add('s3d-full'); veilEl.classList.add('on');
    canvasHost.style.height = (window.innerHeight || 700) + 'px';
    resize(); updateCamera();
  }
  function exitFull(){
    if(!full) return; full = false;
    canvasHost.classList.remove('s3d-full'); veilEl.classList.remove('on');
    document.documentElement.style.overflow = fullPrev; host.style.height = hostPrevH;
    sizeHost(); updateCamera(); renderOnce();
  }
  function feature(b){
    if(featBook) return;
    featBook = b; decorate(b); b.tgtFeat = 1; featYaw = 0.34; featTilt = 0.07;
    setTip(null); enterFull();
    try{ host.scrollIntoView({ block:'center' }); }catch(e){}
    capEl.textContent = b.data.name + (b.data.grau ? '  ·  ' + GRAU_TXT[gkey(b.data.grau)] : '');
    capEl.classList.add('on');
    setTimeout(function(){ if(featBook === b && b.tgtFeat === 1) featEl.classList.add('on'); }, 520);
  }
  function back(){
    var b = featBook; if(!b || b.tgtFeat === 0) return;
    if(b.tgtOpen || b.openP > 0) return;                 // livro aberto: quem fecha é o leitor
    b.tgtFeat = 0; featEl.classList.remove('on'); capEl.classList.remove('on');
  }

  /* ---------- abertura do livro: a capa gira na lombada e mostra a página da imagem ---------- */
  var OPEN_ANG = 2.95;
  function openSingle(){ return (window.innerWidth || 800) < 680; }
  // quebra o texto do item em páginas (linhas já medidas) para escrever direto nas folhas do livro
  function paginateText(src, W, H, u){
    var g = mkCanvas(8, 8).getContext('2d'), fs = 20 * u, lh = 30 * u, maxW = W - 80 * u;
    var cap = Math.max(3, Math.floor((H - 100 * u - 70 * u) / lh)), lines = [], cur = [], cw = 0;
    function fnt(bd){ return (bd ? '700 ' : '400 ') + fs + 'px Fraunces, Georgia, serif'; }
    function flush(){ lines.push(cur); cur = []; cw = 0; }
    if(!String(src || '').trim()) return [[]];
    String(src).split('\n').forEach(function(ln, li){
      if(li > 0) flush();
      var bold = false;
      ln.split('**').forEach(function(seg, si){
        if(si > 0) bold = !bold;
        seg.split(/\s+/).filter(Boolean).forEach(function(w){
          g.font = fnt(bold);
          var ww = g.measureText(w).width, sp = cur.length ? g.measureText(' ').width : 0;
          if(cur.length && cw + sp + ww > maxW){ flush(); sp = 0; }
          cur.push({ w:w, b:bold, sp:sp }); cw += sp + ww;
        });
      });
    });
    if(cur.length || !lines.length) flush();
    var pages = []; for(var i = 0; i < lines.length; i += cap) pages.push(lines.slice(i, i + cap));
    return pages;
  }
  // desenha uma página (papel) em canvas: 'image' = imagem + nome, 'text' = texto do item (página pg), 'blank', 'endpaper' = guarda da capa
  function drawLeaf(cv, b, kind, img, gutter, pg){
    var g = cv.getContext('2d'), w = cv.width, h = cv.height, u = w / 512, d = b.data, i;
    if(kind === 'endpaper'){
      var eg = g.createRadialGradient(w * 0.3, h * 0.2, 10, w * 0.5, h * 0.5, h * 0.8); eg.addColorStop(0, '#3f6352'); eg.addColorStop(1, '#1f3328');
      g.fillStyle = eg; g.fillRect(0, 0, w, h);
      g.strokeStyle = 'rgba(212,175,84,.6)'; g.lineWidth = 2 * u; g.strokeRect(14 * u, 14 * u, w - 28 * u, h - 28 * u);
    }else{
      var pgd = g.createLinearGradient(0, 0, w, 0);
      if(gutter === 'right'){ pgd.addColorStop(0, '#f3ecdb'); pgd.addColorStop(0.9, '#f1e8d2'); pgd.addColorStop(1, '#d9ccab'); }
      else{ pgd.addColorStop(0, '#d9ccab'); pgd.addColorStop(0.1, '#f1e8d2'); pgd.addColorStop(1, '#f3ecdb'); }
      g.fillStyle = pgd; g.fillRect(0, 0, w, h);
      g.strokeStyle = 'rgba(120,90,40,.16)'; g.lineWidth = 10 * u; g.strokeRect(0, 0, w, h);
    }
    var no = 'Nº ' + String(d.no == null ? '' : d.no).padStart(3, '0');
    if(kind === 'image'){
      var m = 34 * u, top = 34 * u, fh = h * 0.72, fw = w - 2 * m;
      g.fillStyle = '#e9dfc6'; g.fillRect(m, top, fw, fh);
      if(img && img.naturalWidth){
        var pad = 8 * u, aw = fw - 2 * pad, ah = fh - 2 * pad, k = Math.min(aw / img.naturalWidth, ah / img.naturalHeight);
        var iw = img.naturalWidth * k, ih = img.naturalHeight * k;
        g.drawImage(img, m + (fw - iw) / 2, top + (fh - ih) / 2, iw, ih);
      }else if(!d.image){
        g.fillStyle = 'rgba(60,45,20,.55)'; g.font = 'italic ' + 22 * u + 'px Georgia, serif'; g.textAlign = 'center';
        g.fillText('sem imagem registrada', w / 2, top + fh / 2);
      }
      g.strokeStyle = '#1b2a22'; g.lineWidth = 2 * u; g.strokeRect(m, top, fw, fh);
      g.textAlign = 'left'; g.fillStyle = '#2f6f6a';
      g.font = 15 * u + 'px "Space Mono", monospace'; g.fillText(no, m, top + fh + 34 * u);
      var fs = 44 * u, name = String(d.name || '');
      do{ g.font = 'italic 700 ' + fs + 'px Fraunces, Georgia, serif'; fs -= 2 * u; }while(g.measureText(name).width > fw && fs > 16 * u);
      g.fillStyle = '#1b2a22'; g.fillText(name, m, top + fh + 34 * u + 16 * u + fs + 6 * u);
      var gl = [d.cat, d.grau ? (GRAU_TXT[gkey(d.grau)] || '') : ''].filter(Boolean).join('  ·  ');
      if(gl){ g.fillStyle = '#7a5f2a'; g.font = 14 * u + 'px "Space Mono", monospace'; g.fillText(gl.toUpperCase(), m, h - 52 * u); }
      g.fillStyle = 'rgba(60,45,20,.6)'; g.font = 12 * u + 'px "Space Mono", monospace';
      if(d.created) g.fillText('Catalogado em ' + new Date(d.created).toLocaleDateString('pt-BR'), m, h - 22 * u);
      g.font = 14 * u + 'px "Space Mono", monospace'; g.textAlign = 'center'; g.fillText('1', w / 2, h - 22 * u);
    }else if(kind === 'text'){
      var m2 = 40 * u, L = (b.texts && b.texts[pg - 1]) || [];
      g.textAlign = 'left'; g.fillStyle = '#2f6f6a'; g.font = 13 * u + 'px "Space Mono", monospace';
      g.fillText('O QUE ESTE ITEM FAZ', m2, 52 * u);
      g.strokeStyle = 'rgba(120,90,40,.4)'; g.lineWidth = 1.5 * u; g.beginPath(); g.moveTo(m2, 64 * u); g.lineTo(w - m2, 64 * u); g.stroke();
      g.fillStyle = '#2a2216';
      if(!L.length){ g.fillStyle = 'rgba(60,45,20,.55)'; g.font = 'italic ' + 20 * u + 'px Georgia, serif'; g.fillText('Nenhum registro sobre o que este item faz ainda.', m2, 124 * u); }
      L.forEach(function(ln, li){
        var x = m2, y = 120 * u + li * 30 * u;
        ln.forEach(function(t){ g.font = (t.b ? '700 ' : '400 ') + 20 * u + 'px Fraunces, Georgia, serif'; x += t.sp; g.fillText(t.w, x, y); x += g.measureText(t.w).width; });
      });
      g.fillStyle = 'rgba(60,45,20,.6)'; g.font = 14 * u + 'px "Space Mono", monospace'; g.textAlign = 'center'; g.fillText(String(pg + 1), w / 2, h - 22 * u);
    }else if(kind === 'blank'){
      g.fillStyle = 'rgba(60,45,20,.3)'; g.font = 40 * u + 'px Georgia, serif'; g.textAlign = 'center'; g.fillText('\u2766', w / 2, h / 2);
    }
  }
  function leafPlane(b, pw, ph, gutter){
    var cv = mkCanvas(768, Math.max(96, Math.round(768 * ph / pw)));
    var mat = new T.MeshStandardMaterial({ map:tex(cv), roughness:0.92, metalness:0, envMapIntensity:0.2 });
    var mesh = new T.Mesh(new T.PlaneGeometry(pw, ph), mat);
    mesh.userData.cv = cv; mesh.userData.gutter = gutter; mesh.userData.idx = null;
    return mesh;
  }
  // idx: -1 = guarda da capa, 0 = imagem/nome, 1.. = páginas de texto, null = página em branco
  function setLeaf(mesh, b, idx){
    var u = mesh.userData; u.idx = idx;
    drawLeaf(u.cv, b, idx === -1 ? 'endpaper' : idx === null ? 'blank' : idx === 0 ? 'image' : 'text', b.img || null, u.gutter, idx);
    mesh.material.map.needsUpdate = true;
  }
  function leftIdx(b, s){ return b.single ? -1 : 2 * s; }
  function rightIdx(b, s){ return b.single ? s : 2 * s + 1; }
  function pageIdx(b, i){ return (i === -1 || i < b.M) ? i : null; }
  function setSpread(b, s){ b.sp = s; setLeaf(b.pL, b, pageIdx(b, leftIdx(b, s))); setLeaf(b.pR, b, pageIdx(b, rightIdx(b, s))); }
  function prepareOpen(b){
    if(b.pivot) return;
    var g = b.mesh, ud = g.userData, th = b.th, h = b.h, dp = b.dp, ct = ud.ct, s = ud.s, lb = ud.lb;
    var hx = th / 2 - ct, hz = dp / 2 - s, single = openSingle();
    var pv = new T.Group(); pv.position.set(hx, 0, hz); g.add(pv);
    g.children.slice().forEach(function(c){                // capa da frente + relevo dourado + cantoneiras vão para a dobradiça
      if(c === pv || c.position.x <= 0.0001) return;
      c.position.set(c.position.x - hx, c.position.y, c.position.z - hz); pv.add(c);
    });
    var pz0 = -dp / 2 + 0.035, pz1 = dp / 2 - s + 0.012, pw = pz1 - pz0 - 0.01, ph = h - 0.08, xr = (th - 2 * ct + 0.004) / 2 + 0.003, zc = (pz0 + pz1) / 2;
    b.single = single; b.img = null; b.flip = null;
    b.texts = paginateText(b.data.content, 768, Math.round(768 * ph / pw), 1.5);
    b.M = 1 + b.texts.length; b.nSp = single ? b.M : Math.ceil(b.M / 2);
    var inner = leafPlane(b, lb - 0.04, h - 0.05, 'right');
    inner.rotation.y = -Math.PI / 2; inner.position.set(-0.004, 0, -lb / 2); pv.add(inner);
    var right = leafPlane(b, pw, ph, 'left');
    right.rotation.y = Math.PI / 2; right.position.set(xr, 0, zc); g.add(right);
    var fp = new T.Group(); fp.position.set(xr + 0.012, 0, zc + pw / 2); fp.visible = false; g.add(fp);   // folha que vira, presa na lombada
    var ff = leafPlane(b, pw, ph, 'left'), fb = leafPlane(b, pw, ph, 'right');
    ff.rotation.y = Math.PI / 2; ff.position.set(0, 0, -pw / 2); fb.rotation.y = -Math.PI / 2; fb.position.set(-0.0005, 0, -pw / 2);
    fp.add(ff); fp.add(fb);
    b.pL = inner; b.pR = right; b.fp = fp; b.fF = ff; b.fB = fb;
    b.pivot = pv; b.openP = 0; b.tgtOpen = 0; b.handed = false;
    setSpread(b, 0);
    if(b.data.image){                                      // a imagem do item entra quando terminar de carregar
      var im = new Image(); if(String(b.data.image).slice(0, 5) !== 'data:') im.crossOrigin = 'anonymous';
      im.onload = function(){ try{ b.img = im; [b.pL, b.pR, b.fF, b.fB].forEach(function(mm){ if(mm.userData.idx === 0) setLeaf(mm, b, 0); }); renderOnce(); }catch(e){} };
      im.src = b.data.image;
    }
  }
  function openIt(){
    var b = featBook; if(!b || b.tgtFeat !== 1 || b.tgtOpen) return;
    prepareOpen(b);
    if(b.sp !== 0) setSpread(b, 0);
    featEl.classList.remove('on'); setTip(null);
    b.tgtOpen = 1; b.handed = false;
  }

  /* ---------- leitura: virar páginas e ações, tudo no próprio livro ---------- */
  function refreshReader(){
    var b = featBook; if(!b || !b.pivot) return;
    var s = b.flip ? b.flip.n : b.sp, a = b.single ? s + 1 : 2 * s + 1, e = b.single ? s + 1 : Math.min(2 * s + 2, b.M);
    rdPos.textContent = (e > a ? a + '–' + e : a) + ' de ' + b.M;
    rdPrev.disabled = s <= 0 || !!b.flip; rdNext.disabled = s >= b.nSp - 1 || !!b.flip;
  }
  function flipBy(dir){
    var b = featBook; if(!b || !b.pivot || !b.tgtOpen || b.openP < 1 || b.flip) return;
    var n = b.sp + dir; if(n < 0 || n >= b.nSp) return;
    var nl = pageIdx(b, leftIdx(b, n)), nr = pageIdx(b, rightIdx(b, n)), ol = b.pL.userData.idx, or = b.pR.userData.idx;
    if(dir > 0){ setLeaf(b.fF, b, or); setLeaf(b.fB, b, nl); setLeaf(b.pR, b, nr); b.fp.rotation.y = 0; }
    else{ setLeaf(b.fB, b, ol); setLeaf(b.fF, b, nr); setLeaf(b.pL, b, nl); b.fp.rotation.y = -OPEN_ANG; }
    b.fp.visible = true; b.flip = { d:dir, t:0, n:n, nl:nl, nr:nr };
    refreshReader();
  }
  function endFlip(b){
    var f = b.flip; if(!f) return;
    if(f.d > 0) setLeaf(b.pL, b, f.nl); else setLeaf(b.pR, b, f.nr);
    b.fp.visible = false; b.sp = f.n; b.flip = null; refreshReader();
  }
  function stepFlip(b, dt){
    var f = b.flip; if(!f) return;
    f.t += dt / 0.75; var e = ease(Math.min(1, f.t));
    b.fp.rotation.y = -OPEN_ANG * (f.d > 0 ? e : 1 - e);
    if(f.t >= 1) endFlip(b);
  }
  function closeIt(after){
    var b = featBook; if(!b || !b.pivot || !b.tgtOpen) return;
    endFlip(b); rdEl.classList.remove('on');
    b.tgtOpen = 0; b.handed = false; b.afterClose = !!after;
  }
  function removeIt(){
    var b = featBook; if(!b || !opts.onRemove) return;
    Promise.resolve(opts.onRemove(b.id)).then(function(){ closeIt(true); }, function(){});
  }

  /* ---------- laço de desenho ---------- */
  var camPos = new T.Vector3();
  function poseBook(b, dt){
    var m = b.mesh, e = ease(b.feat);
    var eo = b.pivot ? ease(b.openP) : 0;
    if(b.pivot) b.pivot.rotation.y = -eo * OPEN_ANG;
    if(b.feat <= 0){ m.position.set(b.x, b.y, b.z + b.hv * 0.3); m.quaternion.copy(b.q0); m.scale.set(1, 1, 1); return; }
    var par = m.parent; camera.updateMatrixWorld(); par.updateWorldMatrix(true, false);
    var vh = 2 * Math.tan(camera.fov * Math.PI / 360) * FDIST, vw = vh * camera.aspect;
    var sT = Math.min(vh * 0.62 / b.h, vw * 0.74 / (b.dp * 0.96), 2.8);
    var sgl = openSingle();
    if(eo > 0 && !sgl){ var sO = Math.min(sT, vw * 0.8 / (2 * b.dp)); sT = sT + (sO - sT) * eo; }     // livro aberto cabe na tela (2 páginas)
    tV.set(sgl ? 0 : eo * (b.dp - 0.05) * sT * 0.5, vh * 0.05, -FDIST); camera.localToWorld(tV); par.worldToLocal(tV);   // lombada vai para o centro
    var fy = featYaw * (1 - 0.85 * eo) + (drag ? 0 : Math.sin(timeS * 0.7) * 0.05 * (1 - eo));
    tQ.setFromAxisAngle(AX_Y, -Math.PI / 2 + fy); tQ2.setFromAxisAngle(AX_X, featTilt * (1 - 0.5 * eo) + (drag ? 0 : Math.sin(timeS * 0.5) * 0.015 * (1 - eo))); tQ2.multiply(tQ);
    camera.getWorldQuaternion(camQ); camQ.multiply(tQ2);
    par.getWorldQuaternion(parQ).invert(); parQ.multiply(camQ);
    m.quaternion.copy(b.q0).slerp(parQ, e);
    m.position.set(b.x, b.y, b.z + b.hv * 0.3).lerp(tV, e);
    m.position.z += Math.sin(Math.PI * e) * 0.9;
    var s = 1 + (sT - 1) * e; m.scale.set(s, s, s);
  }
  function frame(now){
    raf = 0; if(!running) return;
    var dt = Math.min(0.12, ((now || 0) - lastT) / 1000 || 0.016); lastT = now || 0; timeS += dt;
    if(host.offsetWidth > 0 && document.visibilityState === 'visible'){
      if(featBook){ yaw += (0 - yaw) * ap(6, dt); yawVel = 0; }
      else if(!drag){ yaw += yawVel * 0.9; yawVel *= 0.9; yaw = Math.max(-0.6, Math.min(0.6, yaw)); if(Math.abs(yawVel) < 0.0004) yawVel = 0; }
      root.rotation.y = yaw;
      fitW += (tgtW - fitW) * ap(6, dt); fitTop += (tgtTop - fitTop) * ap(6, dt);
      var n = cases.length;
      cases.forEach(function(c, i){
        var rt = i - selIdx; c.rk += (rt - c.rk) * ap(7, dt); if(Math.abs(rt - c.rk) < 0.003) c.rk = rt;
        placeCase(c);
      });
      updateCamera();
      var sc = cases[selIdx];
      if(sc && sc.booksG){
        sc.books.forEach(function(b){
          b.hv += (((b === hovered && !featBook) ? 1 : 0) - b.hv) * ap(14, dt);
          b.feat += (b.tgtFeat - b.feat) * ap(4.6, dt); if(Math.abs(b.tgtFeat - b.feat) < 0.003) b.feat = b.tgtFeat;
          if(b.pivot && b.openP !== b.tgtOpen){
            var stp = dt / (b.tgtOpen ? 1.7 : 0.9);
            b.openP = b.tgtOpen ? Math.min(1, b.openP + stp) : Math.max(0, b.openP - stp);
            if(b.tgtOpen && b.openP >= 1 && !b.handed){
              b.handed = true;
              setTimeout(function(){ if(featBook === b && b.tgtOpen){ refreshReader(); rdEl.classList.add('on'); } }, 160);
            }
            if(!b.tgtOpen && b.openP <= 0 && featBook === b && b.tgtFeat === 1){ if(b.afterClose){ b.afterClose = false; back(); } else featEl.classList.add('on'); }
          }
          if(b.flip) stepFlip(b, dt);
          poseBook(b, dt);
          if(b.extras) b.extras.forEach(function(x){ x.visible = b.feat > 0.02; });
        });
      }
      var fe = featBook ? ease(featBook.feat) : 0;
      dimPlane.material.opacity = 0.74 * fe; dimPlane.visible = fe > 0.01;
      featLight.intensity = 0.3 * fe;
      if(featBook && featBook.tgtFeat === 0 && featBook.feat === 0){
        featBook = null; exitFull();
        if(pendingData){ pendingData = false; build(); }
      }
      renderer.render(scene, camera);
    }
    raf = requestAnimationFrame(frame);
  }
  function renderOnce(){ if(renderer && host.offsetWidth > 0){ updateCamera(); renderer.render(scene, camera); } }
  function start(){ if(running) return; running = true; if(!raf) raf = requestAnimationFrame(frame); }
  function stop(){ running = false; if(raf){ cancelAnimationFrame(raf); raf = 0; } }
  function onKey(ev){
    var t = ev.target; if(t && (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.isContentEditable)) return;
    if(!featBook) return;
    if(ev.key === 'Escape'){ if(featBook.tgtOpen) closeIt(); else back(); }
    else if(featBook.tgtOpen){ if(ev.key === 'ArrowRight') flipBy(1); else if(ev.key === 'ArrowLeft') flipBy(-1); }
  }

  /* ---------- API ---------- */
  S.init = function(h, o){
    if(S.ready) return true;
    try{ return initInner(h, o); }
    catch(e){
      try{ console.error('Shelf3D:', e); if(renderer){ renderer.dispose(); if(renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement); } }catch(_){}
      renderer = null; S.ready = false; if(o && o.onFail) o.onFail('Este aparelho não conseguiu montar o modo 3D.'); return false;
    }
  };
  function initInner(h, o){
    opts = o || {}; host = h; injectCss();
    try{
      renderer = new T.WebGLRenderer({ antialias:true, alpha:true, powerPreference:'high-performance' });
    }catch(e){ if(opts.onFail) opts.onFail('Este aparelho não conseguiu abrir o modo 3D.'); return false; }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x000000, 0);
    renderer.outputEncoding = T.sRGBEncoding; renderer.toneMapping = T.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.95;
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = T.PCFSoftShadowMap;
    canvasHost = host.querySelector('.s3d-canvas'); tipEl = host.querySelector('.s3d-tip'); msgEl = host.querySelector('.s3d-msg'); hintEl = host.querySelector('.s3d-hint');
    tabsEl = host.querySelector('.s3d-tabs');
    if(!tabsEl){ tabsEl = document.createElement('div'); tabsEl.className = 's3d-tabs'; tabsEl.hidden = true; host.insertBefore(tabsEl, canvasHost); }
    veilEl = document.createElement('div'); veilEl.className = 's3d-veil'; canvasHost.appendChild(veilEl);
    canvasHost.appendChild(renderer.domElement);
    capEl = document.createElement('div'); capEl.className = 's3d-cap'; canvasHost.appendChild(capEl);
    featEl = document.createElement('div'); featEl.className = 's3d-feat';
    var bOpen = document.createElement('button'); bOpen.type = 'button'; bOpen.className = 's3d-primary'; bOpen.textContent = '📖 Abrir livro';
    var bBack = document.createElement('button'); bBack.type = 'button'; bBack.textContent = 'Voltar à estante';
    bOpen.addEventListener('click', openIt); bBack.addEventListener('click', back);
    featEl.appendChild(bOpen); featEl.appendChild(bBack); canvasHost.appendChild(featEl);
    rdEl = document.createElement('div'); rdEl.className = 's3d-feat s3d-read';
    function rdBtn(txt, fn){ var x = document.createElement('button'); x.type = 'button'; x.textContent = txt; x.addEventListener('click', fn); rdEl.appendChild(x); return x; }
    rdPrev = rdBtn('‹ Anterior', function(){ flipBy(-1); });
    rdPos = document.createElement('span'); rdPos.className = 's3d-pos'; rdEl.appendChild(rdPos);
    rdNext = rdBtn('Próxima ›', function(){ flipBy(1); });
    var rdBr = document.createElement('i'); rdBr.className = 's3d-br'; rdEl.appendChild(rdBr);
    if(opts.onEdit) rdBtn('Editar', function(){ if(featBook) opts.onEdit(featBook.id); }).setAttribute('data-adm', '1');
    if(opts.onRemove) rdBtn('Remover', removeIt).setAttribute('data-adm', '1');
    rdBtn('Fechar livro', function(){ closeIt(); });
    canvasHost.appendChild(rdEl);
    renderer.domElement.setAttribute('aria-label', 'Estantes 3D de itens. Estantes lado a lado: toque numa delas para trazê-la de frente e toque em um livro para pegá-lo.');
    renderer.domElement.style.cssText = 'display:block;width:100%;height:100%;touch-action:pan-y;cursor:var(--cur-grab,grab);';
    scene = new T.Scene();
    camera = new T.PerspectiveCamera(34, 1, 0.1, 300); scene.add(camera);
    scene.fog = new T.Fog(0x241a12, 20, 60);
    root = new T.Group(); scene.add(root);
    scene.add(new T.HemisphereLight(0xfff3df, 0x4a3320, 0.5));
    sun = new T.DirectionalLight(0xffe9c8, 0.85); sun.position.set(-9, 12, 18); sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048); sun.shadow.bias = -0.0005; sun.shadow.normalBias = 0.02; sun.shadow.radius = 3;
    scene.add(sun); scene.add(sun.target);
    var fill = new T.PointLight(0xffc27a, 0.4, 90); fill.position.set(8, 4, 16); scene.add(fill);
    var rim = new T.DirectionalLight(0xbcd2ff, 0.22); rim.position.set(10, 6, -6); scene.add(rim);
    featLight = new T.PointLight(0xfff1d6, 0, 40); featLight.position.set(2.5, 3, 1); camera.add(featLight);
    dimPlane = new T.Mesh(new T.PlaneGeometry(90, 90), new T.MeshBasicMaterial({ color:0x000000, transparent:true, opacity:0, depthWrite:false }));
    dimPlane.position.set(0, 0, -(FDIST + 4)); dimPlane.renderOrder = 5; dimPlane.visible = false; dimPlane.frustumCulled = false; camera.add(dimPlane);
    makeEnv();
    woodTex = makeWood(); pageTex = makePageTex(); makeLeather(); makeSpineBump();
    ray = new T.Raycaster(); mouse = new T.Vector2();
    var el = renderer.domElement;
    el.addEventListener('pointerdown', onDown); el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerup', onUp); el.addEventListener('pointercancel', function(){ drag = null; });
    el.addEventListener('pointerleave', onLeave);
    el.addEventListener('wheel', function(ev){ if(ev.ctrlKey || ev.metaKey){ ev.preventDefault(); S.zoomBy(ev.deltaY < 0 ? 1.08 : 0.93); } }, { passive:false });
    el.addEventListener('webglcontextlost', function(ev){ ev.preventDefault(); stop(); });
    el.addEventListener('webglcontextrestored', function(){ build(); if(active) start(); });
    document.addEventListener('keydown', onKey);
    var lastCls = -1;
    ro = new ResizeObserver(function(){
      var w = host.clientWidth; if(!w) return;
      var cls = (window.innerWidth || 600) < 560 ? 0 : 1;
      if(lastCls !== cls){ lastCls = cls; if(!featBook) build(); }
      else { if(!full) sizeHost(); else { canvasHost.style.height = (window.innerHeight || 700) + 'px'; resize(); } renderOnce(); }
    });
    ro.observe(host); ro.observe(document.documentElement);
    window.addEventListener('resize', function(){ if(full){ canvasHost.style.height = (window.innerHeight || 700) + 'px'; resize(); } });
    if(document.fonts && document.fonts.ready) document.fonts.ready.then(function(){ if(cases.length && !featBook) build(); });
    S.ready = true; if(active) start();
    return true;
  }
  S.setData = function(rows){
    lastData = rows || [];
    if(!S.ready) return;
    if(featBook){ pendingData = true; return; }
    build();
  };
  S.select = function(id){ for(var i = 0; i < cases.length; i++) if(cases[i].id === id){ select(i); return; } selId = id; };
  S.back = back;
  S.bookClosed = function(){ var b = featBook; if(b && b.pivot){ b.tgtOpen = 0; b.handed = false; if(b.openP <= 0 && b.tgtFeat === 1) featEl.classList.add('on'); } };
  S.setActive = function(on){ active = !!on; if(!S.ready) return; if(on){ start(); resize(); renderOnce(); } else { stop(); if(featBook){ featBook.feat = 0; featBook.tgtFeat = 0; if(featBook.pivot){ featBook.openP = 0; featBook.tgtOpen = 0; } featBook = null; exitFull(); featEl.classList.remove('on'); rdEl.classList.remove('on'); capEl.classList.remove('on'); } } };
  S.zoomBy = function(f){ zoom = Math.max(0.4, Math.min(2.2, zoom * f)); renderOnce(); };
  S.reset = function(){ if(featBook){ back(); return; } yaw = 0; yawVel = 0; pitch = 0.09; zoom = 1; renderOnce(); };
  S.dispose = function(){ stop(); document.removeEventListener('keydown', onKey); if(ro) ro.disconnect(); disposeAll(); if(renderer){ renderer.dispose(); if(renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement); } S.ready = false; };
})();
