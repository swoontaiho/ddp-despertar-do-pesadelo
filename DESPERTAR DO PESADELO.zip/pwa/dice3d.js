/* Dados 3D do combate (d4, d6, d8, d10, d12, d20) — versão 4.
   - Modelo: arestas com bisel curvo de 4 segmentos (perfil de Bézier), cantos arredondados em dois anéis e normais
     interpoladas, então a luz escorrega pela borda como num dado de resina de verdade.
   - Números: gravados em baixo-relevo (mapa de normais gerado a partir do próprio algarismo), com tinta no fundo da
     gravação, contorno de sombra e reflexo próprio.
   - Texturas: procedurais em 3D (o dado é "esculpido" de dentro de um bloco, sem emenda nem repetição) com relevo,
     rugosidade e brilho variando ponto a ponto. Acabamentos: resina marmorizada, mármore, metal escovado, cristal,
     granito, madeira, galáxia e brasa. Cada dado sorteia um pedaço diferente do bloco, então dois d6 nunca são iguais.
   - O estilo (cor do dado, cor dos números, acabamento) é escolhido em Minha conta → Dados 3D e viaja junto com a
     jogada, então todo mundo vê o dado do jeito de quem rolou.
   - Os dados ficam pouco tempo na tela: rolam rápido, assentam, ficam um instante e somem (o tempo é ajustável).
   - O resultado de cada dado já vem decidido: a animação só gira o dado até a face certa ficar virada para a tela.
     Posições e giros saem de uma "semente" (seed), então todo mundo no combate vê a mesma jogada. */
(function(){
  'use strict';
  const T = window.THREE;
  if(!T) return;
  const DEF = { 4:'#2f8f67', 6:'#b5423a', 8:'#3566b5', 10:'#7d4db5', 12:'#c08f26', 20:'#2a8f9c' };
  const MAT_DEF = { wood:'#8b5a2b', lava:'#ff6a1a' };            // cor padrão de alguns acabamentos quando a pessoa não escolheu cor
  const MATS = ['plastic', 'marble', 'metal', 'glass', 'stone', 'wood', 'galaxy', 'lava'];
  // m = metalicidade, r = rugosidade, cc/ccr = verniz, env = força do reflexo do ambiente, bump = força do relevo,
  // rng = o quanto o "bloco" é deslocado de um dado para outro
  const FIN = {
    plastic:{ m:.02, r:.3,  cc:.9, ccr:.14, env:1,    bump:.7,  rng:20 },
    marble: { m:0,   r:.24, cc:1,  ccr:.07, env:1.05, bump:.4,  rng:20 },
    metal:  { m:.95, r:.3,  cc:0,  ccr:0,   env:1.3,  bump:1,   rng:20 },
    glass:  { m:0,   r:.05, cc:1,  ccr:.03, env:1.8,  bump:.8,  rng:20, alpha:.72 },
    stone:  { m:0,   r:.88, cc:0,  ccr:0,   env:.5,   bump:1.2, rng:20 },
    wood:   { m:0,   r:.55, cc:.5, ccr:.32, env:.7,   bump:1,   rng:2.4 },
    galaxy: { m:.15, r:.22, cc:1,  ccr:.05, env:1.15, bump:.35, rng:20 },
    lava:   { m:0,   r:.85, cc:0,  ccr:0,   env:.35,  bump:1.5, rng:20 }
  };
  const geoCache = {}, grpCache = {}, texCache = {}, nrmCache = {}, numMatCache = {};
  let renderer = null, scene = null, camera = null, layer = null, ro = null, raf = 0, fadeT = 0, clearT = 0;
  let dice = [], W = 1, H = 1;
  const ZAX = new T.Vector3(0, 0, 1);
  const lin = hex => new T.Color(hex).convertSRGBToLinear();

  function rng(seed){
    let a = (seed >>> 0) || 1;
    return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  }
  const okHex = v => typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v);
  function cleanStyle(st){
    st = st || {};
    return { body: okHex(st.body) ? st.body.toLowerCase() : '', num: okHex(st.num) ? st.num.toLowerCase() : '#ffffff', mat: MATS.includes(st.mat) ? st.mat : 'plastic' };
  }

  // ---------- geometria ----------
  function d10Geo(){
    const k = .105, c = Math.cos(Math.PI / 5), h = k * (1 + c) / (1 - c);
    const U = [], L = [];
    for(let i = 0; i < 5; i++){
      const a = i * 2 * Math.PI / 5, b = a + Math.PI / 5;
      U.push(new T.Vector3(Math.cos(a), Math.sin(a), k));
      L.push(new T.Vector3(Math.cos(b), Math.sin(b), -k));
    }
    const top = new T.Vector3(0, 0, h), bot = new T.Vector3(0, 0, -h), pos = [];
    const tri = (a, b, c2) => {
      const n = new T.Vector3().subVectors(b, a).cross(new T.Vector3().subVectors(c2, a));
      const ctr = new T.Vector3().add(a).add(b).add(c2);
      (n.dot(ctr) < 0 ? [a, c2, b] : [a, b, c2]).forEach(p => pos.push(p.x, p.y, p.z));
    };
    for(let i = 0; i < 5; i++){
      const j = (i + 1) % 5;
      tri(top, U[i], L[i]); tri(top, L[i], U[j]);
      tri(bot, L[i], U[j]); tri(bot, U[j], L[j]);
    }
    const g = new T.BufferGeometry();
    g.setAttribute('position', new T.Float32BufferAttribute(pos, 3));
    return g;
  }
  function baseGeo(s){
    if(s === 4) return new T.TetrahedronGeometry(1);
    if(s === 6) return new T.BoxGeometry(1.2, 1.2, 1.2).toNonIndexed();
    if(s === 8) return new T.OctahedronGeometry(1);
    if(s === 10) return d10Geo();
    if(s === 12) return new T.DodecahedronGeometry(1);
    return new T.IcosahedronGeometry(1);
  }
  const q3 = x => (Math.abs(x) < 5e-4 ? 0 : x).toFixed(3);
  const vkey = v => q3(v.x) + ',' + q3(v.y) + ',' + q3(v.z);

  // junta os triângulos coplanares em faces (com os vértices em ordem em volta do centro)
  function faceList(geo){
    const p = geo.attributes.position, faces = [];
    for(let i = 0; i < p.count; i += 3){
      const a = new T.Vector3().fromBufferAttribute(p, i), b = new T.Vector3().fromBufferAttribute(p, i + 1), c = new T.Vector3().fromBufferAttribute(p, i + 2);
      const n = new T.Vector3().subVectors(b, a).cross(new T.Vector3().subVectors(c, a)).normalize();
      let f = faces.find(q => q.normal.dot(n) > .999);
      if(!f){ f = { normal:n, verts:[] }; faces.push(f); }
      [a, b, c].forEach(v => { if(!f.verts.some(w => w.distanceToSquared(v) < 1e-6)) f.verts.push(v); });
    }
    faces.forEach(f => {
      f.center = f.verts.reduce((s, v) => s.add(v), new T.Vector3()).multiplyScalar(1 / f.verts.length);
      const u = f.verts[0].clone().sub(f.center).normalize(), w = new T.Vector3().crossVectors(f.normal, u);
      const ang = v => { const d = v.clone().sub(f.center); return Math.atan2(d.dot(w), d.dot(u)); };
      f.ring = f.verts.slice().sort((p1, q1) => ang(p1) - ang(q1));
      let r = Infinity;
      for(let i = 0; i < f.ring.length; i++){
        const A = f.ring[i], B = f.ring[(i + 1) % f.ring.length], e = new T.Vector3().subVectors(B, A), len = e.length();
        if(len > 1e-6) r = Math.min(r, new T.Vector3().subVectors(f.center, A).cross(e).length() / len);
      }
      f.inr = isFinite(r) && r > 1e-4 ? r : .5;
    });
    return faces;
  }
  function assignValues(faces, s){
    const n = faces.length, val = new Array(n).fill(0); let v = 1;
    for(let i = 0; i < n; i++){
      if(val[i]) continue;
      val[i] = v;
      const j = faces.findIndex((q, idx) => idx !== i && !val[idx] && q.normal.dot(faces[i].normal) < -.999);
      if(j >= 0 && s !== 4) val[j] = n + 1 - v;
      v++;
      while(val.includes(v) && v <= n) v++;
    }
    faces.forEach((f, i) => f.value = val[i]);
  }

  // dado com borda arredondada: cada face encolhe um pouco; as arestas viram faixas com perfil curvo (Bézier de 4
  // segmentos, tangente às duas faces) e os cantos viram um "chapéu" de dois anéis, tudo com normais interpoladas.
  function chamfer(faces, k){
    const SEG = 4, RND = .55;
    const pos = [], nor = [];
    const put = v => { pos.push(v.p.x, v.p.y, v.p.z); nor.push(v.n.x, v.n.y, v.n.z); };
    const tri = (a, b, c) => {
      const n = new T.Vector3().subVectors(b.p, a.p).cross(new T.Vector3().subVectors(c.p, a.p));
      const ctr = new T.Vector3().add(a.p).add(b.p).add(c.p);
      (n.dot(ctr) < 0 ? [a, c, b] : [a, b, c]).forEach(put);
    };
    const fan = pts => { for(let i = 1; i < pts.length - 1; i++) tri(pts[0], pts[i], pts[i + 1]); };
    const inner = faces.map(f => f.ring.map(v => ({ p:v.clone().lerp(f.center, k), n:f.normal })));
    faces.forEach((f, i) => fan(inner[i]));
    // perfil curvo entre o canto da face 1 e o canto da face 2 (o ponto de controle é o vértice original)
    const profile = (P1, P2, orig) => {
      const out = [P1];
      for(let i = 1; i < SEG; i++){
        const t = i / SEG, a = (1 - t) * (1 - t), b = 2 * t * (1 - t), c = t * t;
        out.push({
          p:P1.p.clone().multiplyScalar(a).addScaledVector(orig, b).addScaledVector(P2.p, c),
          n:P1.n.clone().lerp(P2.n, t).normalize()
        });
      }
      out.push(P2);
      return out;
    };
    const edges = {}, corners = {}, ends = {};
    faces.forEach((f, fi) => f.ring.forEach((v, i) => {
      const w = f.ring[(i + 1) % f.ring.length], a = vkey(v), b = vkey(w), ek = a < b ? a + '|' + b : b + '|' + a;
      (edges[ek] = edges[ek] || []).push({ fi, i, j:(i + 1) % f.ring.length });
      (corners[a] = corners[a] || []).push({ fi, i, v });
    }));
    Object.keys(edges).forEach(ek => {
      const e = edges[ek]; if(e.length !== 2) return;
      const [A, B] = e, f1 = faces[A.fi], f2 = faces[B.fi];
      const find = (f, key) => f.ring.findIndex(v => vkey(v) === key);
      const vA = f1.ring[A.i], wA = f1.ring[A.j];
      const P1 = inner[A.fi][A.i], Q1 = inner[A.fi][A.j];
      const P2 = inner[B.fi][find(f2, vkey(vA))], Q2 = inner[B.fi][find(f2, vkey(wA))];
      const pa = profile(P1, P2, vA), pb = profile(Q1, Q2, wA);
      for(let i = 0; i < SEG; i++) fan([pa[i], pb[i], pb[i + 1], pa[i + 1]]);
      (ends[vkey(vA)] = ends[vkey(vA)] || []).push(pa);
      (ends[vkey(wA)] = ends[vkey(wA)] || []).push(pb);
    });
    Object.keys(corners).forEach(key => {
      const list = corners[key], V = list[0].v, ax = V.clone().normalize();
      if(list.length < 3) return;
      const u = new T.Vector3().crossVectors(ax, Math.abs(ax.z) < .9 ? ZAX : new T.Vector3(1, 0, 0)).normalize(), w = new T.Vector3().crossVectors(ax, u);
      const set = new Set();
      list.forEach(it => set.add(inner[it.fi][it.i]));
      (ends[key] || []).forEach(pr => pr.forEach(q => set.add(q)));
      const pts = Array.from(set);
      if(pts.length < 3) return;
      const ctr = pts.reduce((s, q) => s.add(q.p), new T.Vector3()).multiplyScalar(1 / pts.length);
      const nC = list.reduce((s, it) => s.add(faces[it.fi].normal), new T.Vector3()).normalize();
      const hub = { p:ctr.clone().lerp(V, RND * .8), n:nC };
      const ang = q => { const d = q.p.clone().sub(ctr); return Math.atan2(d.dot(w), d.dot(u)); };
      const ring = pts.slice().sort((a, b) => ang(a) - ang(b));
      const ring1 = ring.map(q => ({ p:q.p.clone().lerp(hub.p, .5), n:q.n.clone().lerp(nC, .5).normalize() }));
      for(let i = 0; i < ring.length; i++){
        const j = (i + 1) % ring.length;
        fan([ring[i], ring[j], ring1[j], ring1[i]]);
        tri(hub, ring1[i], ring1[j]);
      }
    });
    const g = new T.BufferGeometry();
    g.setAttribute('position', new T.Float32BufferAttribute(pos, 3));
    g.setAttribute('normal', new T.Float32BufferAttribute(nor, 3));
    return g;
  }
  function geoFor(s){
    if(geoCache[s]) return geoCache[s];
    const base = baseGeo(s); base.computeVertexNormals();
    const faces = faceList(base); assignValues(faces, s);
    const k = s === 6 ? .17 : s === 4 ? .12 : .1;
    return geoCache[s] = { geo:chamfer(faces, k), faces, k };
  }

  // ---------- números gravados ----------
  const NS = 256;
  function lum(hex){ const c = new T.Color(hex); return .299 * c.r + .587 * c.g + .114 * c.b; }
  function glyph(x, txt, under, mode, width){
    x.textAlign = 'center'; x.textBaseline = 'middle'; x.lineJoin = 'round';
    x.font = '700 ' + (txt.length > 1 ? 132 : 168) + 'px "Fraunces", Georgia, serif';
    if(width){ x.lineWidth = width; x.strokeText(txt, 128, 118); }
    if(mode !== 'stroke') x.fillText(txt, 128, 118);
    if(under){
      if(width){ x.lineWidth = Math.max(3, width * .45); x.strokeRect(76, 206, 104, 15); }
      if(mode !== 'stroke') x.fillRect(76, 206, 104, 15);
    }
  }
  function blur(src, n, r){                    // desfoque de caixa (3 passadas ≈ gaussiano), em arrays de n×n
    let a = src, b = new Float32Array(n * n);
    for(let pass = 0; pass < 3; pass++){
      for(let y = 0; y < n; y++){                       // horizontal
        let acc = 0; const row = y * n;
        for(let x = -r; x <= r; x++) acc += a[row + Math.min(n - 1, Math.max(0, x))];
        for(let x = 0; x < n; x++){
          b[row + x] = acc / (2 * r + 1);
          acc += a[row + Math.min(n - 1, x + r + 1)] - a[row + Math.max(0, x - r)];
        }
      }
      for(let x = 0; x < n; x++){                       // vertical
        let acc = 0;
        for(let y = -r; y <= r; y++) acc += b[Math.min(n - 1, Math.max(0, y)) * n + x];
        for(let y = 0; y < n; y++){
          a[y * n + x] = acc / (2 * r + 1);
          acc += b[Math.min(n - 1, y + r + 1) * n + x] - b[Math.max(0, y - r) * n + x];
        }
      }
    }
    return a;
  }
  // mapa de normais do algarismo gravado (a cavidade é o próprio número com o contorno)
  function numNormal(txt, under){
    const key = txt + '|' + (under ? 1 : 0);
    if(nrmCache[key]) return nrmCache[key];
    const m = document.createElement('canvas'); m.width = m.height = NS;
    const mx = m.getContext('2d'); mx.fillStyle = mx.strokeStyle = '#fff';
    glyph(mx, txt, under, 'both', 14);
    const id = mx.getImageData(0, 0, NS, NS).data, B = new Float32Array(NS * NS);
    for(let i = 0; i < NS * NS; i++) B[i] = id[i * 4 + 3] / 255;
    blur(B, NS, 4);
    const cv = document.createElement('canvas'); cv.width = cv.height = NS;
    const cx = cv.getContext('2d'), out = cx.createImageData(NS, NS), d = out.data, K = 7;
    for(let y = 0; y < NS; y++) for(let x = 0; x < NS; x++){
      const xl = B[y * NS + Math.max(0, x - 1)], xr = B[y * NS + Math.min(NS - 1, x + 1)];
      const yu = B[Math.max(0, y - 1) * NS + x], yd = B[Math.min(NS - 1, y + 1) * NS + x];
      let nx = (xr - xl) * K, ny = -(yd - yu) * K, nz = 1;                // cavidade: a parede aponta para dentro
      const l = Math.sqrt(nx * nx + ny * ny + nz * nz); nx /= l; ny /= l; nz /= l;
      const o = (y * NS + x) * 4;
      d[o] = (nx * .5 + .5) * 255; d[o + 1] = (ny * .5 + .5) * 255; d[o + 2] = (nz * .5 + .5) * 255; d[o + 3] = 255;
    }
    cx.putImageData(out, 0, 0);
    const t = new T.CanvasTexture(cv); t.anisotropy = 8;
    return nrmCache[key] = t;
  }
  function numTex(txt, under, color){
    const key = txt + '|' + color + '|' + (under ? 1 : 0);
    if(texCache[key]) return texCache[key];
    const cv = document.createElement('canvas'); cv.width = cv.height = NS;
    const x = cv.getContext('2d');
    const light = lum(color) > .5;
    // contorno escuro (ou claro, se o número for escuro): a "parede" da gravação, onde a luz do mapa de normais aparece
    x.fillStyle = x.strokeStyle = light ? 'rgba(0,0,0,.62)' : 'rgba(255,255,255,.5)';
    glyph(x, txt, under, 'stroke', 14);
    if(under) x.fillRect(76, 206, 104, 15);
    // tinta no fundo da gravação, com um leve degradê (mais clara em cima)
    const gr = x.createLinearGradient(0, 40, 0, 210), c0 = new T.Color(color);
    const hi = '#' + c0.clone().lerp(new T.Color(0xffffff), .18).getHexString(), lo = '#' + c0.clone().lerp(new T.Color(0x000000), .16).getHexString();
    gr.addColorStop(0, hi); gr.addColorStop(1, lo);
    x.fillStyle = gr; x.strokeStyle = gr;
    glyph(x, txt, under, 'fill', 0);
    const t = new T.CanvasTexture(x.canvas); t.anisotropy = 8; t.encoding = T.sRGBEncoding;
    return texCache[key] = t;
  }
  function numMat(txt, under, color){
    const key = txt + '|' + color + '|' + (under ? 1 : 0);
    if(numMatCache[key]) return numMatCache[key];
    return numMatCache[key] = new T.MeshStandardMaterial({
      map:numTex(txt, under, color), normalMap:numNormal(txt, under), normalScale:new T.Vector2(1.15, 1.15),
      roughness:.4, metalness:.2, envMapIntensity:.9, transparent:true, depthWrite:false,
      polygonOffset:true, polygonOffsetFactor:-2, polygonOffsetUnits:-2
    });
  }

  // ---------- materiais do corpo (texturas procedurais em 3D) ----------
  const GL_PARS = `
varying vec3 vObj; varying float vScl;
uniform vec3 uOff; uniform vec3 uCol2; uniform vec3 uGlow; uniform float uBump;
float dh31(vec3 p){ p = fract(p * .3183099 + .1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float dnoise(vec3 x){
  vec3 i = floor(x), f = fract(x); f = f * f * (3. - 2. * f);
  return mix(mix(mix(dh31(i), dh31(i + vec3(1,0,0)), f.x), mix(dh31(i + vec3(0,1,0)), dh31(i + vec3(1,1,0)), f.x), f.y),
             mix(mix(dh31(i + vec3(0,0,1)), dh31(i + vec3(1,0,1)), f.x), mix(dh31(i + vec3(0,1,1)), dh31(i + vec3(1,1,1)), f.x), f.y), f.z);
}
float dfbm(vec3 p){ float a = .5, s = 0.; for(int i = 0; i < 5; i++){ s += a * dnoise(p); p = p * 2.03 + vec3(1.7, 9.2, 3.1); a *= .5; } return s; }
vec3 dicePerturb(vec3 sp, vec3 sn, vec2 dh, float fd){
  vec3 sx = dFdx(sp), sy = dFdy(sp);
  vec3 r1 = cross(sy, sn), r2 = cross(sn, sx);
  float det = dot(sx, r1) * fd;
  vec3 g = sign(det) * (dh.x * r1 + dh.y * r2);
  return normalize(abs(det) * sn - g);
}`;
  const GL_HEAD = `
vec3 dBase = diffuseColor.rgb; vec3 dP = vObj + uOff;
float dH = 0.; float dRough = -1.; float dMetal = -1.; vec3 dEmis = vec3(0.);
`;
  const GL = {
    plastic: `
float w = dfbm(dP * 2.1);
float sw = dfbm(dP * 1.15 + w * 2.2);
float band = smoothstep(.28, .78, sw);
vec3 c = mix(dBase * .58, dBase * 1.22, band);
float vein = pow(1. - abs(2. * dfbm(dP * 1.7 + w * 1.5) - 1.), 9.);
c = mix(c, uCol2, vein * .22);
c += uCol2 * step(.994, dh31(floor(dP * 55.))) * .5;
diffuseColor.rgb = c;
dH = (dfbm(dP * 30.) - .5) * .0018;`,
    marble: `
vec3 q = dP * 1.25;
float w = dfbm(q * 1.4);
float t = q.x * 1.7 + q.y * .9 + q.z * .6 + w * 4.2;
float veinA = pow(1. - abs(sin(t * 3.14159)), 10.);
float t2 = q.z * 2.4 - q.x * .7 + dfbm(q * 3.1 + 7.) * 3.4;
float veinB = pow(1. - abs(sin(t2 * 3.14159)), 14.);
float cloud = dfbm(q * 2.3 + 3.);
vec3 c = dBase * (.78 + .4 * cloud);
c = mix(c, uCol2, clamp(veinA * .9 + veinB * .55, 0., 1.));
c = mix(c, dBase * .35, pow(1. - abs(sin((t * 1.7 + 1.3) * 3.14159)), 24.) * .55);
diffuseColor.rgb = c;
dRough = .18 + .16 * cloud;`,
    metal: `
vec3 q = dP;
float s1 = dnoise(vec3(q.x * 2., q.y * 38., q.z * 2.));
float s2 = dnoise(vec3(q.x * 4., q.y * 76., q.z * 4.));
float st = s1 * .6 + s2 * .4;
float pat = dfbm(q * 2.5);
vec3 c = dBase * (.82 + .3 * st) * (.92 + .16 * pat);
float scr = pow(dnoise(vec3(q.x * 1.5, q.y * 30. + q.z * 12., q.z * 14.)), 9.);
c += uCol2 * scr * .5;
diffuseColor.rgb = c;
dRough = .22 + .24 * st + .15 * pat + scr * .3;
dH = (st - .5) * .006 - scr * .01;`,
    glass: `
float n = dfbm(dP * 2.4);
float inc = pow(dfbm(dP * 5.5 + 3.), 3.);
float bub = (1. - smoothstep(0., .1, length(fract(dP * 9.) - .5))) * step(.9, dh31(floor(dP * 9.)));
vec3 c = dBase * (.75 + .5 * n) + uCol2 * inc * .35;
c = mix(c, uCol2, bub * .5);
diffuseColor.rgb = c;
diffuseColor.a = clamp(diffuseColor.a * (.78 + .55 * n) + inc * .12 + bub * .2, .4, .93);
dH = (n - .5) * .03;`,
    stone: `
vec3 q = dP;
float g = dfbm(q * 7.);
float sp = dnoise(q * 48.);
vec3 c = dBase * (.7 + .55 * g);
c = mix(c, dBase * 1.7 + vec3(.05), smoothstep(.72, .82, sp) * .7);
c = mix(c, dBase * .25, (1. - smoothstep(.12, .24, sp)) * .6);
float vein = pow(1. - abs(2. * dfbm(q * 2.2) - 1.), 12.);
c = mix(c, uCol2 * .9, vein * .3);
diffuseColor.rgb = c;
dH = (dfbm(q * 12.) - .5) * .07 + (sp - .5) * .015;
dRough = .86 - .2 * smoothstep(.8, .9, sp);
dMetal = smoothstep(.86, .92, sp) * .7;`,
    wood: `
vec3 q = dP * vec3(1., .35, 1.);
float warp = dfbm(q * 1.6) * .55;
float rr = length(q.xz + vec2(warp * .4, warp * .3)) * 8. + warp * 5.;
float ring = fract(rr);
float late = smoothstep(0., .55, ring) * (1. - smoothstep(.78, 1., ring));
float fib = dfbm(vec3(q.x * 38., q.y * 2.2, q.z * 38.));
vec3 c = dBase * mix(.5, 1.18, late);
c *= .86 + .28 * fib;
float pores = smoothstep(.6, .9, dnoise(vec3(q.x * 90., q.y * 6., q.z * 90.)));
c *= 1. - .22 * pores;
diffuseColor.rgb = c;
dH = (fib - .5) * .006 - pores * .006 + ring * .004;
dRough = .5 + .2 * fib;`,
    galaxy: `
vec3 q = dP * 1.3;
float n1 = dfbm(q * 1.1);
float n2 = dfbm(q * 2.6 + vec3(5., 1., 9.));
float neb = smoothstep(.32, .8, n1) * (.45 + .75 * n2);
vec3 c = dBase * .05 + dBase * neb * 1.25;
c = mix(c, uCol2, smoothstep(.55, .9, n2) * neb * .55);
vec3 sc = dP * 34.; vec3 ci = floor(sc); vec3 cf = fract(sc) - .5;
vec3 jt = vec3(dh31(ci + 1.7), dh31(ci + 4.1), dh31(ci + 7.3)) - .5;
float star = (1. - smoothstep(0., .2, length(cf - jt * .7))) * step(.8, dh31(ci));
vec3 sc2 = dP * 12.; vec3 ci2 = floor(sc2); vec3 cf2 = fract(sc2) - .5;
vec3 jt2 = vec3(dh31(ci2 + 2.3), dh31(ci2 + 5.9), dh31(ci2 + 8.1)) - .5;
float star2 = (1. - smoothstep(0., .14, length(cf2 - jt2 * .6))) * step(.86, dh31(ci2 + 3.));
c += vec3(1., .96, .88) * (star + star2);
diffuseColor.rgb = c;
dEmis = vec3(1., .95, .85) * (star + star2) * 1.4;
dRough = .2;
dH = (dfbm(dP * 25.) - .5) * .002;`,
    lava: `
vec3 q = dP * 1.5;
float n = dfbm(q * 1.7);
float crack = 1. - smoothstep(0., .05, abs(n - .5));
float n2 = dfbm(q * 4.2 + vec3(3., 8., 1.));
float crack2 = 1. - smoothstep(0., .03, abs(n2 - .5));
float cr = clamp(crack + crack2 * .75, 0., 1.);
float g = dfbm(q * 6.);
vec3 rock = mix(vec3(.018, .015, .014), vec3(.085, .07, .065), g) + dBase * .02;
diffuseColor.rgb = mix(rock, uGlow * .55, cr * cr);
dEmis = uGlow * cr * (.55 + .9 * dfbm(q * 3. + 11.)) * 1.6;
dH = g * .03 + dfbm(q * 14.) * .008 - cr * .045;
dRough = .88;`
  };
  function bodyMat(st, s, off){
    const fin = MATS.includes(st.mat) ? st.mat : 'plastic', P = FIN[fin];
    const hex = st.body || MAT_DEF[fin] || DEF[s];
    const c1 = new T.Color(hex);
    const dark = lum(hex) < .16;
    const col2 = c1.clone().lerp(new T.Color(0xffffff), fin === 'galaxy' ? .55 : fin === 'stone' ? .35 : .8).convertSRGBToLinear();
    const glow = (dark ? new T.Color(0xff6a1a) : c1.clone().lerp(new T.Color(0xffffff), .2)).convertSRGBToLinear();
    const opts = { color:lin(hex), metalness:P.m, roughness:P.r, envMapIntensity:P.env };
    if(P.cc){ opts.clearcoat = P.cc; opts.clearcoatRoughness = P.ccr; }
    if(P.alpha){ opts.transparent = true; opts.opacity = P.alpha; }
    const m = new T.MeshPhysicalMaterial(opts);
    const U = { uOff:{ value:off }, uCol2:{ value:col2 }, uGlow:{ value:glow }, uBump:{ value:P.bump } };
    m.customProgramCacheKey = () => 'dice4_' + fin;
    m.onBeforeCompile = shader => {
      Object.assign(shader.uniforms, U);
      shader.vertexShader = shader.vertexShader
        .replace('#include <common>', '#include <common>\nvarying vec3 vObj; varying float vScl;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvObj = position; vScl = length(modelViewMatrix[0].xyz);');
      shader.fragmentShader = shader.fragmentShader
        .replace('#include <common>', '#include <common>\n' + GL_PARS)
        .replace('#include <color_fragment>', '#include <color_fragment>\n' + GL_HEAD + '{\n' + GL[fin] + '\n}')
        .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\nif(dRough >= 0.) roughnessFactor = dRough;')
        .replace('#include <metalnessmap_fragment>', '#include <metalnessmap_fragment>\nif(dMetal >= 0.) metalnessFactor = dMetal;')
        .replace('#include <normal_fragment_maps>', '#include <normal_fragment_maps>\nnormal = dicePerturb(-vViewPosition, normal, vec2(dFdx(dH), dFdy(dH)) * vScl * uBump, faceDirection);')
        .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\ntotalEmissiveRadiance += dEmis;');
    };
    return m;
  }
  const PLACEHOLDER = new T.MeshBasicMaterial();
  function groupFor(s, st){                          // casco + números (o material do casco é colocado em cada dado)
    const key = s + '|' + st.num;
    if(grpCache[key]) return grpCache[key];
    if(Object.keys(grpCache).length > 60) Object.keys(grpCache).slice(0, 20).forEach(k => delete grpCache[k]);
    const { geo, faces, k } = geoFor(s);
    const g = new T.Group();
    g.add(new T.Mesh(geo, PLACEHOLDER));
    faces.forEach(f => {
      const far = f.verts.reduce((b, v) => (v.distanceTo(f.center) > b.distanceTo(f.center) ? v : b), f.verts[0]);
      const y = far.clone().sub(f.center); y.sub(f.normal.clone().multiplyScalar(y.dot(f.normal))).normalize();
      const x = new T.Vector3().crossVectors(y, f.normal).normalize();
      const sz = Math.min(f.inr * (1 - k) * 1.7, 1.12) * (s === 4 ? .9 : 1);
      const m = new T.Mesh(new T.PlaneGeometry(sz, sz), numMat(String(f.value), (f.value === 6 || f.value === 9) && s >= 8, st.num));
      m.matrixAutoUpdate = false;
      m.matrix.makeBasis(x, y, f.normal).setPosition(f.center.clone().add(f.normal.clone().multiplyScalar(.005)));
      g.add(m);
    });
    return grpCache[key] = g;
  }
  function dieGroup(s, st, off){
    const g = groupFor(s, st).clone();
    g.children[0].material = bodyMat(st, s, off);
    return g;
  }
  function freeBody(g){ const m = g && g.children[0] && g.children[0].material; if(m && m !== PLACEHOLDER) m.dispose(); }
  function offsetFor(fin, r){ const R = FIN[fin].rng; return new T.Vector3((r() - .5) * 2 * R, (r() - .5) * 2 * R, (r() - .5) * 2 * R); }

  // ambiente (reflexos): céu em degradê, chão escuro e painéis de luz (softboxes) fortes, para brilhos bem marcados
  function makeEnv(rd){
    try{
      const sc = new T.Scene();
      const sg = new T.SphereGeometry(50, 48, 24), col = [], p = sg.attributes.position;
      for(let i = 0; i < p.count; i++){
        const y = p.getY(i) / 50, c = y > 0 ? new T.Color(0x56606c).lerp(new T.Color(0xdfe9ff), y) : new T.Color(0x56606c).lerp(new T.Color(0x14171b), -y);
        col.push(c.r, c.g, c.b);
      }
      sg.setAttribute('color', new T.Float32BufferAttribute(col, 3));
      sc.add(new T.Mesh(sg, new T.MeshBasicMaterial({ vertexColors:true, side:T.BackSide })));
      [[-25, 30, 25, 26, 14, 0xffffff, 3], [30, 12, 18, 14, 10, 0xffe2c0, 2.4], [0, -8, 32, 30, 5, 0xc9d0da, 1.4], [-34, -4, 8, 9, 22, 0xb8d0ff, 1.8], [10, 38, 4, 22, 8, 0xffffff, 2.2]].forEach(([x, y, z, w, h, c, k]) => {
        const m = new T.Mesh(new T.PlaneGeometry(w, h), new T.MeshBasicMaterial({ color:new T.Color(c).multiplyScalar(k), side:T.DoubleSide }));
        m.position.set(x, y, z); m.lookAt(0, 0, 0); sc.add(m);
      });
      const pm = new T.PMREMGenerator(rd), tex = pm.fromScene(sc, .02).texture; pm.dispose();
      return tex;
    }catch(e){ console.error('Ambiente dos dados:', e); return null; }
  }
  function baseRenderer(cv){
    const r = new T.WebGLRenderer({ alpha:true, antialias:true, canvas:cv || undefined });
    r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    r.setClearColor(0x000000, 0); r.outputEncoding = T.sRGBEncoding;
    return r;
  }
  function addLights(sc){
    sc.add(new T.AmbientLight(0xffffff, .38));
    const dl = new T.DirectionalLight(0xfff1dd, .7); dl.position.set(-.5, .8, 1); sc.add(dl);
    const rim = new T.DirectionalLight(0xbfd6ff, .34); rim.position.set(.9, -.4, .6); sc.add(rim);
    const fill = new T.DirectionalLight(0xffffff, .14); fill.position.set(.3, -.9, .8); sc.add(fill);
  }

  let shadowTex = null, shadowGeo = null;
  function shadowMat(){
    if(!shadowTex){
      const cv = document.createElement('canvas'); cv.width = cv.height = 64; const x = cv.getContext('2d');
      const gr = x.createRadialGradient(32, 32, 2, 32, 32, 32); gr.addColorStop(0, 'rgba(0,0,0,.55)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
      x.fillStyle = gr; x.fillRect(0, 0, 64, 64); shadowTex = new T.CanvasTexture(cv);
    }
    return new T.MeshBasicMaterial({ map:shadowTex, transparent:true, depthWrite:false });
  }
  function shadowGeom(){ return shadowGeo || (shadowGeo = new T.PlaneGeometry(1, 1)); }

  // ---------- arena ----------
  function resize(){
    if(!renderer || !layer) return;
    const w = layer.clientWidth, h = layer.clientHeight; if(!w || !h) return;
    W = w; H = h;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.position.z = (h / 2) / Math.tan(camera.fov * Math.PI / 360);
    camera.far = camera.position.z * 4; camera.updateProjectionMatrix();
    if(dice.length && !raf) renderer.render(scene, camera);      // redimensionar apaga a imagem: redesenha os dados parados
  }
  function mount(el){
    layer = el;
    if(!renderer){
      renderer = baseRenderer(null);
      scene = new T.Scene(); scene.environment = makeEnv(renderer);
      camera = new T.PerspectiveCamera(30, 1, 1, 5000);
      addLights(scene);
      renderer.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block';
    }
    if(renderer.domElement.parentNode !== layer) layer.insertBefore(renderer.domElement, layer.firstChild);
    if(ro) ro.disconnect();
    if(window.ResizeObserver){ ro = new ResizeObserver(resize); ro.observe(layer); }
    resize();
  }

  const ease = t => 1 - Math.pow(1 - t, 3);
  const HOLD_DEF = 1500;              // tempo que o dado fica parado na tela depois de rolar (ms)
  function clearDice(){
    dice.forEach(d => { scene.remove(d.group); scene.remove(d.shadow); d.shadow.material.dispose(); freeBody(d.group); });
    dice = [];
  }
  function frame(now){
    raf = 0;
    if(!renderer || !dice.length) return;
    const minWH = Math.min(W, H);
    let alive = false;
    dice.forEach(d => {
      const t = Math.min(1, Math.max(0, (now - d.t0 - d.delay) / d.dur)), e = ease(t), R = d.rf * minWH;
      const tp = (now - d.t0 - d.delay - d.dur) / 240;                       // "tranco" ao assentar
      const pop = tp > 0 && tp < 1 ? Math.sin(tp * Math.PI) * .07 : 0;
      if(t < 1 || tp < 1) alive = true;
      const fx = d.sx + (d.tx - d.sx) * e, fy = d.sy + (d.ty - d.sy) * e;
      const px = (fx - .5) * W, py = (.5 - fy) * H;
      const hgt = Math.pow(1 - t, 1.3) * Math.abs(Math.sin(t * Math.PI * 2.6)) * R * 3.8;
      d.group.visible = d.shadow.visible = now >= d.t0 + d.delay;
      d.group.position.set(px, py, hgt);
      d.group.scale.setScalar(R * (1 + pop));
      d.group.quaternion.setFromAxisAngle(d.axis, d.ang0 * Math.pow(1 - t, 2)).multiply(d.qT);
      d.shadow.position.set(px + R * .15 + hgt * .15, py - R * .15 - hgt * .12, -R * .95);
      d.shadow.scale.setScalar(R * 2.4 * (1 + hgt / (R * 6)));
      d.shadow.material.opacity = Math.max(.15, 1 - hgt / (R * 5));
    });
    renderer.render(scene, camera);
    if(alive) raf = requestAnimationFrame(frame);       // com os dados parados não precisa redesenhar a cada quadro
  }

  /* spec: { dice:[{s:20, v:13}, ...], seed:123456, hold:1500, style:{body,num,mat} }
     hold = quanto tempo os dados ficam parados na tela depois de assentar (ms). */
  function roll(spec){
    if(!renderer || !layer) return false;
    clearTimeout(fadeT); clearTimeout(clearT); clearDice();
    layer.style.transition = 'none'; layer.style.opacity = '1';
    const r = rng(spec.seed || 1), ro2 = rng(((spec.seed || 1) ^ 0x9e3779b9) >>> 0);       // ro2: só o "pedaço do bloco" de cada dado
    const list = spec.dice.slice(0, 40), n = list.length, st = cleanStyle(spec.style);
    const hold = Number.isFinite(+spec.hold) ? Math.max(300, Math.min(15000, +spec.hold)) : HOLD_DEF;
    resize();
    const aspect = W / H;
    const cols = Math.max(1, Math.ceil(Math.sqrt(n * aspect * .7 / .5))), rows = Math.ceil(n / cols);
    const cellW = .72 / cols, cellH = .52 / rows;
    const rf = Math.max(.038, Math.min(.105, Math.min(cellW * W, cellH * H) * .46 / Math.min(W, H)));
    const now = performance.now();
    let lastEnd = 0;
    list.forEach((it, i) => {
      const face = geoFor(it.s).faces.find(f => f.value === it.v) || geoFor(it.s).faces[0];
      const g = dieGroup(it.s, st, offsetFor(st.mat, ro2)); scene.add(g);
      const sh = new T.Mesh(shadowGeom(), shadowMat()); scene.add(sh);
      const col = i % cols, row = Math.floor(i / cols), inRow = row === rows - 1 ? n - row * cols : cols;
      const tx = .5 + ((col + .5 + (cols - inRow) / 2) / cols - .5) * .72 + (r() - .5) * .025;
      const ty = .44 + ((row + .5) / rows - .5) * .52 + (r() - .5) * .025;
      const side = Math.floor(r() * 4), along = .15 + r() * .7;
      const sx = side === 0 ? -.12 : side === 1 ? 1.12 : along, sy = side === 2 ? -.12 : side === 3 ? 1.12 : along;
      const qT = new T.Quaternion().setFromUnitVectors(face.normal, ZAX);
      qT.premultiply(new T.Quaternion().setFromAxisAngle(ZAX, (r() - .5) * 1.0));
      const axis = new T.Vector3(r() - .5, r() - .5, r() - .5).normalize();
      const delay = Math.min(i * 45, 600), dur = 900 + r() * 300;
      lastEnd = Math.max(lastEnd, delay + dur);
      dice.push({ group:g, shadow:sh, s:it.s, v:it.v, tx, ty, sx, sy, rf, qT, axis, ang0:(2 + r() * 1.8) * Math.PI * 2, t0:now, delay, dur });
    });
    if(!raf) raf = requestAnimationFrame(frame);
    const total = lastEnd + hold;
    fadeT = setTimeout(() => { layer.style.transition = 'opacity .35s'; layer.style.opacity = '0'; }, total);
    clearT = setTimeout(() => { clearDice(); if(renderer) renderer.render(scene, camera); }, total + 450);
    return true;
  }

  // ---------- pré-visualização (editor de estilo) ----------
  // Gira sozinha; dá para arrastar com o dedo/mouse para ver o dado de todos os lados (rolagem vertical da página continua).
  function preview(cv){
    const rd = baseRenderer(cv), sc = new T.Scene(), cam = new T.PerspectiveCamera(30, 1, .1, 50);
    sc.environment = makeEnv(rd); addLights(sc); cam.position.z = 5.2;
    let st = cleanStyle(), cur = null, id = 0, kind = 20, ux = 0, uy = 0, drag = null, rest = 0;
    const holder = new T.Group(); sc.add(holder);
    const offR = rng(20261011);
    const offs = {}; MATS.forEach(m => offs[m] = offsetFor(m, offR));
    const build = () => { if(cur){ holder.remove(cur); freeBody(cur); } cur = dieGroup(kind, st, offs[st.mat]); holder.add(cur); };
    cv.style.touchAction = 'pan-y'; cv.style.cursor = 'grab';
    cv.addEventListener('pointerdown', e => { drag = { x:e.clientX, y:e.clientY }; try{ cv.setPointerCapture(e.pointerId); }catch(err){} cv.style.cursor = 'grabbing'; });
    cv.addEventListener('pointermove', e => { if(!drag) return; uy += (e.clientX - drag.x) * .011; ux += (e.clientY - drag.y) * .011; drag.x = e.clientX; drag.y = e.clientY; });
    const end = () => { drag = null; rest = performance.now(); cv.style.cursor = 'grab'; };
    cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
    const loop = now => {
      id = requestAnimationFrame(loop);
      const w = cv.clientWidth, h = cv.clientHeight; if(!w || !h) return;
      if(cv.width !== Math.round(w * rd.getPixelRatio()) || cv.height !== Math.round(h * rd.getPixelRatio())){ rd.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); }
      const auto = drag ? 0 : Math.min(1, (now - rest) / 900);            // depois de soltar, volta a girar devagar
      uy += auto * .0052;
      holder.rotation.set(.45 + ux + Math.sin(now / 1700) * .12 * auto, uy, .15);
      rd.render(sc, cam);
    };
    build();
    return {
      set(s2, k){ st = cleanStyle(s2); if(k) kind = k; build(); },
      start(){ if(!id) id = requestAnimationFrame(loop); },
      stop(){ if(id){ cancelAnimationFrame(id); id = 0; } }
    };
  }

  window.Dice3D = { ready:true, mount, roll, resize, preview, cleanStyle, HOLD_DEF, MATS, faces:s => geoFor(s).faces.map(f => f.value) };
})();
