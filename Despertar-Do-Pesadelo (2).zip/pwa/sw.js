/* Service worker do app. Mude VERSAO quando quiser forçar todos a baixarem arquivos novos. */
const VERSAO = 'pesadelo-v44';
const BASE = ['./', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/apple-touch-icon.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSAO).then(c => c.addAll(BASE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSAO).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if(req.method !== 'GET') return;                       // envios (mensagens, fichas…) passam direto
  const url = new URL(req.url);
  if(url.origin !== location.origin) return;             // banco de dados, fontes etc.: nunca guardar aqui
  if(url.searchParams.has('_chk')) return;                // conferência de versão: sempre vai à internet
  if(req.mode === 'navigate'){
    // Página: tenta a internet primeiro (sempre a versão nova); sem internet, usa a guardada.
    e.respondWith(
      fetch(req).then(res => { const c = res.clone(); caches.open(VERSAO).then(ch => ch.put('./', c)); return res; })
        .catch(() => caches.match('./').then(r => r || caches.match(req)))
    );
    return;
  }
  // Scripts (.js) e a página: internet primeiro, para nunca misturar versão nova com versão velha.
  if(/\.js$/.test(url.pathname)){
    e.respondWith(
      fetch(req).then(res => { if(res.ok){ const c = res.clone(); caches.open(VERSAO).then(ch => ch.put(req, c)); } return res; })
        .catch(() => caches.match(req))
    );
    return;
  }
  // Ícones e demais arquivos do próprio site: guardado primeiro, atualiza em segundo plano.
  e.respondWith(
    caches.match(req).then(hit => {
      const net = fetch(req).then(res => { if(res.ok){ const c = res.clone(); caches.open(VERSAO).then(ch => ch.put(req, c)); } return res; }).catch(() => hit);
      return hit || net;
    })
  );
});

// Toque em uma notificação: volta para o app (e abre a conversa, se for mensagem).
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const d = e.notification.data || {};
  e.waitUntil(
    self.clients.matchAll({ type:'window', includeUncontrolled:true }).then(list => {
      const c = list.find(x => 'focus' in x);
      if(c){ c.postMessage({ t:'notif', kind:d.kind, chat:d.chat }); return c.focus(); }
      const hash = d.kind === 'chat' && d.chat ? '#chat=' + encodeURIComponent(d.chat) : '';
      return self.clients.openWindow('./' + hash);
    })
  );
});

// Aviso vindo do servidor (funciona com o app fechado), no estilo de mensagem de chat.
self.addEventListener('push', e => {
  let d = {};
  try{ d = e.data ? e.data.json() : {}; }catch(_){ d = { title:'Nova mensagem', body: e.data ? e.data.text() : '' }; }
  e.waitUntil((async () => {
    const wins = await self.clients.matchAll({ type:'window', includeUncontrolled:true });
    if(wins.some(w => w.visibilityState === 'visible' && w.focused)) return;      // já está olhando o app
    const tag = d.tag || 'msg';
    const ex = await self.registration.getNotifications({ tag });
    if(d.mid && ex.some(n => n.data && n.data.mid === d.mid)) return;               // já mostrado pelo próprio app
    const call = d.kind === 'call';
    await self.registration.showNotification(d.title || 'Nova mensagem', {
      body: d.body || '', icon:'icons/icon-192.png', badge:'icons/icon-192.png', lang:'pt-BR',
      tag, renotify:true, requireInteraction:call, vibrate: call ? [300, 150, 300, 150, 300] : [200, 100, 200],
      data:{ kind:d.kind, chat:d.chat, mid:d.mid }
    });
  })());
});
